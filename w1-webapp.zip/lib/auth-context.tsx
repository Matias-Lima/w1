"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  name: string
  email: string
  role: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message?: string }>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Função auxiliar para obter usuários do localStorage
const getStoredUsers = (): Array<{ id: string; name: string; email: string; password: string; role: string }> => {
  const storedUsers = localStorage.getItem("w1-users")
  if (storedUsers) {
    try {
      return JSON.parse(storedUsers)
    } catch (error) {
      console.error("Erro ao analisar usuários armazenados:", error)
    }
  }

  // Usuários padrão
  const defaultUsers = [
    {
      id: "1",
      name: "Administrador",
      email: "admin@w1.com.br",
      password: "password",
      role: "admin",
    },
    {
      id: "2",
      name: "Cliente Exemplo",
      email: "cliente@exemplo.com",
      password: "password",
      role: "client",
    },
  ]

  // Armazenar usuários padrão
  localStorage.setItem("w1-users", JSON.stringify(defaultUsers))
  return defaultUsers
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for existing session on mount
  useEffect(() => {
    const savedUser = localStorage.getItem("w1-user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (error) {
        localStorage.removeItem("w1-user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Get users from localStorage
    const users = getStoredUsers()

    const foundUser = users.find((u) => u.email === email && u.password === password)

    if (foundUser) {
      const userSession = {
        id: foundUser.id,
        name: foundUser.name,
        email: foundUser.email,
        role: foundUser.role,
      }

      setUser(userSession)
      localStorage.setItem("w1-user", JSON.stringify(userSession))
      setIsLoading(false)
      return true
    }

    setIsLoading(false)
    return false
  }

  const register = async (
    name: string,
    email: string,
    password: string,
  ): Promise<{ success: boolean; message?: string }> => {
    setIsLoading(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Get existing users
    const users = getStoredUsers()

    // Check if email already exists
    if (users.some((user) => user.email === email)) {
      setIsLoading(false)
      return {
        success: false,
        message: "Este email já está em uso. Por favor, use outro email.",
      }
    }

    // Create new user
    const newUser = {
      id: String(Date.now()), // Simple ID generation
      name,
      email,
      password,
      role: "client", // Default role for new users
    }

    // Add to users list
    users.push(newUser)
    localStorage.setItem("w1-users", JSON.stringify(users))

    // Auto login the new user
    const userSession = {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
    }

    setUser(userSession)
    localStorage.setItem("w1-user", JSON.stringify(userSession))

    setIsLoading(false)
    return { success: true }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("w1-user")
  }

  return <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
