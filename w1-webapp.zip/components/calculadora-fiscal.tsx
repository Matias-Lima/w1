"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Calculator, X } from "lucide-react"

type CalculadoraFiscalProps = {
  onClose: () => void
  onCalculationComplete: (result: CalculationResult) => void
}

export type CalculationResult = {
  economiaTotal: number
  economiaPorcentagem: number
  economiaITCMD: number
  economiaIR: number
  economiaOutros: number
  valorPatrimonio: number
  tipoPatrimonio: string
}

export function CalculadoraFiscal({ onClose, onCalculationComplete }: CalculadoraFiscalProps) {
  const [step, setStep] = useState(1)
  const [valorPatrimonio, setValorPatrimonio] = useState("")
  const [tipoPatrimonio, setTipoPatrimonio] = useState("imoveis")
  const [numHerdeiros, setNumHerdeiros] = useState("2")
  const [loading, setLoading] = useState(false)

  const formatCurrency = (value: string | number) => {
    const num = typeof value === "string" ? Number.parseFloat(value.replace(/[^\d]/g, "")) / 100 : value
    return num.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
    })
  }

  const handleValorPatrimonioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remove caracteres não numéricos
    const value = e.target.value.replace(/[^\d]/g, "")

    // Converte para formato de moeda
    if (value) {
      const formattedValue = (Number.parseInt(value) / 100).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL",
        minimumFractionDigits: 2,
      })
      setValorPatrimonio(formattedValue)
    } else {
      setValorPatrimonio("")
    }
  }

  const handleCalculate = () => {
    setLoading(true)

    // Simula um cálculo (em produção, isso seria baseado em regras fiscais reais)
    setTimeout(() => {
      // Extrai apenas os números do valor do patrimônio
      const valorNumerico = Number.parseFloat(valorPatrimonio.replace(/[^\d]/g, "")) / 100

      // Cálculos simplificados para demonstração
      const taxaITCMDPessoaFisica = 0.04 // 4% ITCMD pessoa física
      const taxaITCMDHolding = 0.015 // 1.5% ITCMD via holding
      const economiaITCMD = valorNumerico * (taxaITCMDPessoaFisica - taxaITCMDHolding)

      // Economia de IR depende do tipo de patrimônio
      let economiaIR = 0
      if (tipoPatrimonio === "imoveis") {
        economiaIR = valorNumerico * 0.035 // 3.5% de economia em IR para imóveis
      } else if (tipoPatrimonio === "investimentos") {
        economiaIR = valorNumerico * 0.05 // 5% de economia em IR para investimentos
      } else {
        economiaIR = valorNumerico * 0.025 // 2.5% de economia em IR para empresas
      }

      // Outras economias (custos de inventário, etc.)
      const economiaOutros = valorNumerico * 0.02 // 2% em outras economias

      // Total de economia
      const economiaTotal = economiaITCMD + economiaIR + economiaOutros
      const economiaPorcentagem = (economiaTotal / valorNumerico) * 100

      const result: CalculationResult = {
        economiaTotal,
        economiaPorcentagem,
        economiaITCMD,
        economiaIR,
        economiaOutros,
        valorPatrimonio: valorNumerico,
        tipoPatrimonio,
      }

      onCalculationComplete(result)
      setLoading(false)
    }, 1500)
  }

  return (
    <Card className="w-full bg-white border-gray-200 text-gray-900">
      <CardHeader className="bg-gray-50 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-teal-500" />
            <CardTitle className="text-lg text-gray-900">Calculadora de Economia Fiscal</CardTitle>
          </div>
          <button onClick={onClose} className="text-gray-700 hover:text-gray-900">
            <X className="h-5 w-5" />
          </button>
        </div>
        <CardDescription className="text-gray-700">
          Estime quanto você pode economizar com uma estruturação patrimonial adequada
        </CardDescription>
      </CardHeader>

      <CardContent className="pt-6">
        {step === 1 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="valor-patrimonio" className="text-gray-600">
                Valor aproximado do patrimônio
              </Label>
              <Input
                id="valor-patrimonio"
                value={valorPatrimonio}
                onChange={handleValorPatrimonioChange}
                placeholder="R$ 0,00"
                className="bg-gray-50 border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-teal-500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo-patrimonio" className="text-gray-600">
                Tipo principal de patrimônio
              </Label>
              <Select value={tipoPatrimonio} onValueChange={setTipoPatrimonio}>
                <SelectTrigger className="bg-gray-50 border-gray-300 text-gray-900">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent className="bg-gray-50 border-gray-300 text-gray-900">
                  <SelectItem value="imoveis">Imóveis</SelectItem>
                  <SelectItem value="investimentos">Investimentos financeiros</SelectItem>
                  <SelectItem value="empresas">Participações em empresas</SelectItem>
                  <SelectItem value="misto">Patrimônio misto</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="num-herdeiros" className="text-gray-600">
                Número de herdeiros
              </Label>
              <Select value={numHerdeiros} onValueChange={setNumHerdeiros}>
                <SelectTrigger className="bg-gray-50 border-gray-300 text-gray-900">
                  <SelectValue placeholder="Selecione a quantidade" />
                </SelectTrigger>
                <SelectContent className="bg-gray-50 border-gray-300 text-gray-900">
                  <SelectItem value="1">1 herdeiro</SelectItem>
                  <SelectItem value="2">2 herdeiros</SelectItem>
                  <SelectItem value="3">3 herdeiros</SelectItem>
                  <SelectItem value="4">4 ou mais herdeiros</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex justify-between border-t border-gray-200 bg-white pt-4">
        <Button
          variant="outline"
          onClick={onClose}
          className="border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
        >
          Cancelar
        </Button>
        <Button
          onClick={handleCalculate}
          disabled={!valorPatrimonio || loading}
          className="bg-teal-600 text-white hover:bg-teal-700"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
              Calculando...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              Calcular economia <ArrowRight className="h-4 w-4" />
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
