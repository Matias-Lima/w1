"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Calculator, ChevronDown, ChevronUp, HelpCircle, Info } from "lucide-react"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

type PatrimonioData = {
  valorInicial: number
  tipoPatrimonio: string
  taxaCrescimento: number
  horizonte: number
  numHerdeiros: number
  distribuicaoAtivos: {
    imoveis: number
    investimentos: number
    empresas: number
    outros: number
  }
}

type ResultadoSimulacao = {
  evolucaoPatrimonioComHolding: { ano: number; valor: number }[]
  evolucaoPatrimonioSemHolding: { ano: number; valor: number }[]
  economiaFiscalTotal: number
  economiaITCMD: number
  economiaIR: number
  economiaOutros: number
  protecaoPatrimonial: number
  distribuicaoAtivos: { name: string; value: number }[]
  comparativoImpostos: { name: string; semHolding: number; comHolding: number }[]
}

export function CalculadoraPatrimonial() {
  const [step, setStep] = useState(1)
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false)
  const [loading, setLoading] = useState(false)
  const [resultado, setResultado] = useState<ResultadoSimulacao | null>(null)

  const [patrimonioData, setPatrimonioData] = useState<PatrimonioData>({
    valorInicial: 2000000,
    tipoPatrimonio: "misto",
    taxaCrescimento: 8,
    horizonte: 10,
    numHerdeiros: 2,
    distribuicaoAtivos: {
      imoveis: 50,
      investimentos: 30,
      empresas: 15,
      outros: 5,
    },
  })

  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target

    if (name === "valorInicial") {
      // Remove caracteres não numéricos e converte para número
      const numericValue = Number(value.replace(/[^\d]/g, "")) / 100
      setPatrimonioData((prev) => ({ ...prev, [name]: numericValue }))
    } else if (name === "taxaCrescimento") {
      setPatrimonioData((prev) => ({ ...prev, [name]: Number(value) }))
    } else if (name.startsWith("distribuicao")) {
      const ativo = name.split(".")[1]
      setPatrimonioData((prev) => ({
        ...prev,
        distribuicaoAtivos: {
          ...prev.distribuicaoAtivos,
          [ativo]: Number(value),
        },
      }))
    }
  }

  const handleSelectChange = (name: string, value: string) => {
    setPatrimonioData((prev) => ({ ...prev, [name]: value }))
  }

  const calcularResultados = () => {
    setLoading(true)

    // Simulação de processamento
    setTimeout(() => {
      const { valorInicial, tipoPatrimonio, taxaCrescimento, horizonte, numHerdeiros, distribuicaoAtivos } =
        patrimonioData

      // Calcular evolução do patrimônio com e sem holding
      const evolucaoPatrimonioComHolding = []
      const evolucaoPatrimonioSemHolding = []

      // Taxas de crescimento diferentes para holding e sem holding
      const taxaCrescimentoComHolding = taxaCrescimento / 100 + 0.02 // 2% a mais de crescimento com holding
      const taxaCrescimentoSemHolding = taxaCrescimento / 100

      // Calcular evolução ao longo dos anos
      let valorComHolding = valorInicial
      let valorSemHolding = valorInicial

      for (let ano = 0; ano <= horizonte; ano++) {
        evolucaoPatrimonioComHolding.push({
          ano,
          valor: valorComHolding,
        })

        evolucaoPatrimonioSemHolding.push({
          ano,
          valor: valorSemHolding,
        })

        valorComHolding = valorComHolding * (1 + taxaCrescimentoComHolding)
        valorSemHolding = valorSemHolding * (1 + taxaCrescimentoSemHolding)
      }

      // Calcular economia fiscal
      const valorFinalSemHolding = evolucaoPatrimonioSemHolding[horizonte].valor
      const valorFinalComHolding = evolucaoPatrimonioComHolding[horizonte].valor

      // ITCMD (Imposto sobre Transmissão Causa Mortis e Doação)
      const taxaITCMDPessoaFisica = 0.04 // 4% ITCMD pessoa física
      const taxaITCMDHolding = 0.015 // 1.5% ITCMD via holding
      const economiaITCMD = valorFinalComHolding * (taxaITCMDPessoaFisica - taxaITCMDHolding)

      // Economia de IR depende do tipo de patrimônio
      let taxaIRPessoaFisica = 0.15 // 15% base
      let taxaIRHolding = 0.05 // 5% base

      if (tipoPatrimonio === "imoveis") {
        taxaIRPessoaFisica = 0.15
        taxaIRHolding = 0.055
      } else if (tipoPatrimonio === "investimentos") {
        taxaIRPessoaFisica = 0.175
        taxaIRHolding = 0.06
      } else if (tipoPatrimonio === "empresas") {
        taxaIRPessoaFisica = 0.15
        taxaIRHolding = 0.045
      }

      const economiaIR = valorFinalComHolding * (taxaIRPessoaFisica - taxaIRHolding)

      // Outras economias (custos de inventário, etc.)
      const economiaOutros = valorFinalComHolding * 0.02 // 2% em outras economias

      // Total de economia
      const economiaFiscalTotal = economiaITCMD + economiaIR + economiaOutros

      // Proteção patrimonial (índice de 0 a 100)
      const protecaoPatrimonial = tipoPatrimonio === "empresas" ? 85 : tipoPatrimonio === "imoveis" ? 75 : 80

      // Distribuição de ativos para gráfico de pizza
      const distribuicaoAtivosGrafico = [
        { name: "Imóveis", value: distribuicaoAtivos.imoveis },
        { name: "Investimentos", value: distribuicaoAtivos.investimentos },
        { name: "Empresas", value: distribuicaoAtivos.empresas },
        { name: "Outros", value: distribuicaoAtivos.outros },
      ]

      // Comparativo de impostos
      const comparativoImpostos = [
        {
          name: "ITCMD",
          semHolding: valorFinalSemHolding * taxaITCMDPessoaFisica,
          comHolding: valorFinalComHolding * taxaITCMDHolding,
        },
        {
          name: "IR",
          semHolding: valorFinalSemHolding * taxaIRPessoaFisica,
          comHolding: valorFinalComHolding * taxaIRHolding,
        },
        {
          name: "Outros",
          semHolding: valorFinalSemHolding * 0.03,
          comHolding: valorFinalComHolding * 0.01,
        },
      ]

      setResultado({
        evolucaoPatrimonioComHolding,
        evolucaoPatrimonioSemHolding,
        economiaFiscalTotal,
        economiaITCMD,
        economiaIR,
        economiaOutros,
        protecaoPatrimonial,
        distribuicaoAtivos: distribuicaoAtivosGrafico,
        comparativoImpostos,
      })

      setLoading(false)
      setStep(2)
    }, 1500)
  }

  const handleReset = () => {
    setResultado(null)
    setStep(1)
  }

  const COLORS = ["#0D9488", "#0F766E", "#134E4A", "#042f2e"]

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Simulador de Planejamento Patrimonial</h2>
        <p className="text-gray-700 max-w-3xl mx-auto">
          Compare cenários e visualize o impacto da estruturação patrimonial via holding na evolução e proteção do seu
          patrimônio ao longo do tempo
        </p>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-xl">
        <div className="bg-gray-50 border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-teal-500" />
              <h3 className="text-xl font-semibold text-gray-900">Simulador de Evolução Patrimonial</h3>
            </div>
          </div>
        </div>

        <div className="p-6">
          {step === 1 ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="valorInicial" className="text-gray-600">
                      Valor atual do patrimônio
                    </Label>
                    <Input
                      id="valorInicial"
                      name="valorInicial"
                      value={formatCurrency(patrimonioData.valorInicial)}
                      onChange={handleInputChange}
                      className="bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-500 focus:border-teal-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tipoPatrimonio" className="text-gray-600">
                      Tipo predominante de patrimônio
                    </Label>
                    <Select
                      value={patrimonioData.tipoPatrimonio}
                      onValueChange={(value) => handleSelectChange("tipoPatrimonio", value)}
                    >
                      <SelectTrigger className="bg-gray-50 border-gray-200 text-gray-900">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-50 border-gray-200 text-gray-900">
                        <SelectItem value="imoveis">Imóveis</SelectItem>
                        <SelectItem value="investimentos">Investimentos financeiros</SelectItem>
                        <SelectItem value="empresas">Participações em empresas</SelectItem>
                        <SelectItem value="misto">Patrimônio misto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="horizonte" className="text-gray-600">
                      Horizonte de planejamento
                    </Label>
                    <Select
                      value={patrimonioData.horizonte.toString()}
                      onValueChange={(value) => handleSelectChange("horizonte", value)}
                    >
                      <SelectTrigger className="bg-gray-50 border-gray-200 text-gray-900">
                        <SelectValue placeholder="Selecione o período" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-50 border-gray-200 text-gray-900">
                        <SelectItem value="5">5 anos</SelectItem>
                        <SelectItem value="10">10 anos</SelectItem>
                        <SelectItem value="15">15 anos</SelectItem>
                        <SelectItem value="20">20 anos</SelectItem>
                        <SelectItem value="30">30 anos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="taxaCrescimento" className="text-gray-600">
                      Taxa média de crescimento anual (%)
                    </Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="taxaCrescimento"
                        name="taxaCrescimento"
                        type="number"
                        min="0"
                        max="30"
                        value={patrimonioData.taxaCrescimento}
                        onChange={handleInputChange}
                        className="bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-500 focus:border-teal-500"
                      />
                      <span className="text-gray-900">%</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="numHerdeiros" className="text-gray-600">
                      Número de herdeiros/sucessores
                    </Label>
                    <Select
                      value={patrimonioData.numHerdeiros.toString()}
                      onValueChange={(value) => handleSelectChange("numHerdeiros", value)}
                    >
                      <SelectTrigger className="bg-gray-50 border-gray-200 text-gray-900">
                        <SelectValue placeholder="Selecione a quantidade" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-50 border-gray-200 text-gray-900">
                        <SelectItem value="1">1 herdeiro</SelectItem>
                        <SelectItem value="2">2 herdeiros</SelectItem>
                        <SelectItem value="3">3 herdeiros</SelectItem>
                        <SelectItem value="4">4 herdeiros</SelectItem>
                        <SelectItem value="5">5 ou mais herdeiros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="pt-4">
                    <button
                      type="button"
                      onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                      className="flex items-center text-teal-400 hover:text-teal-300 text-sm"
                    >
                      {showAdvancedOptions ? (
                        <ChevronUp className="h-4 w-4 mr-1" />
                      ) : (
                        <ChevronDown className="h-4 w-4 mr-1" />
                      )}
                      {showAdvancedOptions ? "Ocultar opções avançadas" : "Mostrar opções avançadas"}
                    </button>
                  </div>
                </div>
              </div>

              {showAdvancedOptions && (
                <div className="border-t border-gray-200 pt-6 mt-6">
                  <h4 className="text-gray-900 font-medium mb-4 flex items-center">
                    Distribuição do patrimônio por classe de ativos
                    <HelpCircle className="h-4 w-4 ml-2 text-gray-700" />
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="distribuicao.imoveis" className="text-gray-600">
                            Imóveis (%)
                          </Label>
                          <span className="text-gray-700">{patrimonioData.distribuicaoAtivos.imoveis}%</span>
                        </div>
                        <Input
                          id="distribuicao.imoveis"
                          name="distribuicao.imoveis"
                          type="range"
                          min="0"
                          max="100"
                          value={patrimonioData.distribuicaoAtivos.imoveis}
                          onChange={handleInputChange}
                          className="accent-teal-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="distribuicao.investimentos" className="text-gray-600">
                            Investimentos financeiros (%)
                          </Label>
                          <span className="text-gray-700">{patrimonioData.distribuicaoAtivos.investimentos}%</span>
                        </div>
                        <Input
                          id="distribuicao.investimentos"
                          name="distribuicao.investimentos"
                          type="range"
                          min="0"
                          max="100"
                          value={patrimonioData.distribuicaoAtivos.investimentos}
                          onChange={handleInputChange}
                          className="accent-teal-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="distribuicao.empresas" className="text-gray-600">
                            Participações em empresas (%)
                          </Label>
                          <span className="text-gray-700">{patrimonioData.distribuicaoAtivos.empresas}%</span>
                        </div>
                        <Input
                          id="distribuicao.empresas"
                          name="distribuicao.empresas"
                          type="range"
                          min="0"
                          max="100"
                          value={patrimonioData.distribuicaoAtivos.empresas}
                          onChange={handleInputChange}
                          className="accent-teal-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="distribuicao.outros" className="text-gray-600">
                            Outros ativos (%)
                          </Label>
                          <span className="text-gray-700">{patrimonioData.distribuicaoAtivos.outros}%</span>
                        </div>
                        <Input
                          id="distribuicao.outros"
                          name="distribuicao.outros"
                          type="range"
                          min="0"
                          max="100"
                          value={patrimonioData.distribuicaoAtivos.outros}
                          onChange={handleInputChange}
                          className="accent-teal-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-4">
                    <p className="text-sm text-gray-700">
                      Total:{" "}
                      {patrimonioData.distribuicaoAtivos.imoveis +
                        patrimonioData.distribuicaoAtivos.investimentos +
                        patrimonioData.distribuicaoAtivos.empresas +
                        patrimonioData.distribuicaoAtivos.outros}
                      %
                    </p>
                  </div>
                </div>
              )}

              <div className="flex justify-end pt-6">
                <Button
                  onClick={calcularResultados}
                  disabled={loading}
                  className="bg-teal-600 text-white hover:bg-teal-700"
                >
                  {loading ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                      Calculando...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Simular evolução patrimonial <ArrowRight className="h-4 w-4" />
                    </span>
                  )}
                </Button>
              </div>
            </div>
          ) : (
            resultado && (
              <div className="space-y-8">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-900">Resultados da Simulação</h3>
                  <Button
                    variant="outline"
                    onClick={handleReset}
                    className="border-gray-200 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                  >
                    Nova simulação
                  </Button>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <h4 className="text-lg font-medium text-gray-900 mb-4">Evolução do Patrimônio</h4>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={resultado.evolucaoPatrimonioComHolding.map((item, index) => ({
                          ...item,
                          semHolding: resultado.evolucaoPatrimonioSemHolding[index].valor,
                        }))}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#9CA3AF" />
                        <XAxis dataKey="ano" stroke="#4B5563" />
                        <YAxis stroke="#4B5563" tickFormatter={(value) => `R$ ${(value / 1000000).toFixed(1)}M`} />
                        <Tooltip
                          formatter={(value: number) => [formatCurrency(value), "Valor"]}
                          labelFormatter={(label) => `Ano ${label}`}
                          contentStyle={{ backgroundColor: "#F9FAFB", borderColor: "#D1D5DB", color: "#111827" }}
                        />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="valor"
                          name="Com Holding"
                          stroke="#0D9488"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                          activeDot={{ r: 6 }}
                        />
                        <Line
                          type="monotone"
                          dataKey="semHolding"
                          name="Sem Holding"
                          stroke="#94A3B8"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                          activeDot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <h4 className="text-lg font-medium text-gray-900 mb-4">Economia Fiscal Estimada</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={resultado.comparativoImpostos}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#9CA3AF" />
                          <XAxis dataKey="name" stroke="#4B5563" />
                          <YAxis stroke="#4B5563" tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`} />
                          <Tooltip
                            formatter={(value: number) => [formatCurrency(value), "Valor"]}
                            contentStyle={{ backgroundColor: "#F9FAFB", borderColor: "#D1D5DB", color: "#111827" }}
                          />
                          <Legend />
                          <Bar dataKey="semHolding" name="Sem Holding" fill="#94A3B8" />
                          <Bar dataKey="comHolding" name="Com Holding" fill="#0D9488" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-4 text-center">
                      <p className="text-gray-700 mb-1">Economia total estimada</p>
                      <p className="text-2xl font-bold text-teal-500">
                        {formatCurrency(resultado.economiaFiscalTotal)}
                      </p>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <h4 className="text-lg font-medium text-gray-900 mb-4">Distribuição do Patrimônio</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={resultado.distribuicaoAtivos}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {resultado.distribuicaoAtivos.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value: number) => [`${value}%`, "Percentual"]}
                            contentStyle={{ backgroundColor: "#F9FAFB", borderColor: "#D1D5DB", color: "#111827" }}
                          />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="bg-gray-50 border-gray-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg text-gray-900">Proteção Patrimonial</CardTitle>
                      <CardDescription>Nível de blindagem contra riscos</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-3xl font-bold text-teal-500">{resultado.protecaoPatrimonial}%</p>
                          <p className="text-sm text-gray-700">Com estruturação via holding</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-3xl font-bold text-gray-700">30%</p>
                          <p className="text-sm text-gray-700">Sem estruturação</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-50 border-gray-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg text-gray-900">Economia em ITCMD</CardTitle>
                      <CardDescription>Imposto sobre Transmissão Causa Mortis</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-1">
                        <p className="text-3xl font-bold text-teal-500">{formatCurrency(resultado.economiaITCMD)}</p>
                        <p className="text-sm text-gray-700">Redução de até 62.5% na carga tributária sucessória</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-50 border-gray-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg text-gray-900">Valor Final Projetado</CardTitle>
                      <CardDescription>Após {patrimonioData.horizonte} anos</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-1">
                        <p className="text-3xl font-bold text-teal-500">
                          {formatCurrency(resultado.evolucaoPatrimonioComHolding[patrimonioData.horizonte].valor)}
                        </p>
                        <p className="text-sm text-gray-700">
                          {(
                            (resultado.evolucaoPatrimonioComHolding[patrimonioData.horizonte].valor /
                              resultado.evolucaoPatrimonioSemHolding[patrimonioData.horizonte].valor -
                              1) *
                            100
                          ).toFixed(1)}
                          % superior ao cenário sem holding
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <div className="flex items-start gap-3">
                    <Info className="h-5 w-5 text-teal-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 mb-2">Análise e Recomendações</h4>
                      <p className="text-gray-700 mb-4">
                        Com base na sua simulação, a estruturação patrimonial via holding pode proporcionar benefícios
                        significativos ao longo do tempo:
                      </p>
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start gap-2">
                          <span className="text-teal-500 font-bold">•</span>
                          <span>
                            <strong className="text-gray-900">Economia fiscal expressiva</strong>: Redução de impostos
                            em sucessão patrimonial (ITCMD) e otimização tributária contínua.
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-teal-500 font-bold">•</span>
                          <span>
                            <strong className="text-gray-900">Proteção patrimonial</strong>: Blindagem contra riscos
                            empresariais, pessoais e familiares.
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-teal-500 font-bold">•</span>
                          <span>
                            <strong className="text-gray-900">Sucessão facilitada</strong>: Transferência de bens sem
                            necessidade de inventário judicial.
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-teal-500 font-bold">•</span>
                          <span>
                            <strong className="text-gray-900">Gestão centralizada</strong>: Administração profissional e
                            eficiente dos ativos.
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center pt-4">
                  <Button className="bg-teal-600 text-white hover:bg-teal-700">
                    Agendar consultoria personalizada
                  </Button>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  )
}
