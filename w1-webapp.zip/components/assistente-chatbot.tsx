"use client"

import { useState, useRef, useEffect } from "react"
import {
  ChevronDown,
  ChevronUp,
  Send,
  HelpCircle,
  FileText,
  Clock,
  Calendar,
  Users,
  Briefcase,
  AlertCircle,
  Bot,
  MessageSquare,
  ArrowRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type Message = {
  id: number
  sender: "user" | "bot"
  text: string
  timestamp: Date
}

const PERGUNTAS_FREQUENTES = [
  {
    id: 1,
    text: "Qual é o status atual do meu processo?",
    icon: Clock,
  },
  {
    id: 2,
    text: "Quais documentos preciso enviar?",
    icon: FileText,
  },
  {
    id: 3,
    text: "Quando será a próxima reunião?",
    icon: Calendar,
  },
  {
    id: 4,
    text: "Quem são os responsáveis pelo meu caso?",
    icon: Users,
  },
  {
    id: 5,
    text: "Como funciona a holding patrimonial?",
    icon: Briefcase,
  },
  {
    id: 6,
    text: "Quais são as vantagens fiscais?",
    icon: AlertCircle,
  },
]

export function AssistenteChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      sender: "bot",
      text: "Olá! Sou o assistente virtual da W1 Holding Patrimonial. Como posso ajudá-lo hoje?",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [showGuide, setShowGuide] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const fetchAIResponse = async (messageHistory: Message[]) => {
    try {
      setIsLoading(true)
      setError(null)

      // Converter mensagens para o formato esperado pela API
      const apiMessages = messageHistory.map((msg) => ({
        role: msg.sender === "user" ? "user" : "assistant",
        content: msg.text,
      }))

      // Fazer a chamada para a API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: apiMessages,
        }),
      })

      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`)
      }

      const data = await response.json()

      // Verificar se a resposta contém o campo esperado
      if (!data.response) {
        throw new Error("Formato de resposta inválido")
      }

      return data.response
    } catch (err) {
      console.error("Erro ao processar mensagem:", err)
      setError("Não foi possível obter uma resposta. Por favor, tente novamente.")
      return "Desculpe, estou com dificuldades para processar sua solicitação no momento. Por favor, tente novamente ou entre em contato pelo telefone (11) 3456-7890."
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    // Adiciona mensagem do usuário
    const userMessage: Message = {
      id: Date.now(),
      sender: "user",
      text: inputValue,
      timestamp: new Date(),
    }

    const updatedMessages = [...messages, userMessage]
    setMessages(updatedMessages)
    setInputValue("")

    // Mostra indicador de digitação
    setIsLoading(true)

    // Obtém resposta da IA
    const aiResponse = await fetchAIResponse(updatedMessages)

    // Adiciona resposta do bot
    const botResponse: Message = {
      id: Date.now() + 1,
      sender: "bot",
      text: aiResponse,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, botResponse])
  }

  const handleQuickQuestion = async (question: string) => {
    if (isLoading) return

    // Adiciona a pergunta rápida como mensagem do usuário
    const userMessage: Message = {
      id: Date.now(),
      sender: "user",
      text: question,
      timestamp: new Date(),
    }

    const updatedMessages = [...messages, userMessage]
    setMessages(updatedMessages)

    // Mostra indicador de digitação
    setIsLoading(true)

    // Obtém resposta da IA
    const aiResponse = await fetchAIResponse(updatedMessages)

    // Adiciona resposta do bot
    const botResponse: Message = {
      id: Date.now() + 1,
      sender: "bot",
      text: aiResponse,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, botResponse])
  }

  // Rola para a última mensagem quando uma nova é adicionada
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  return (
    <Tabs defaultValue="chat" className="w-full">
      <TabsList className="grid w-full grid-cols-2 mb-6 bg-primary text-primary-foreground rounded-xl overflow-hidden">
        <TabsTrigger
          value="chat"
          className="text-lg py-4 data-[state=active]:bg-primary/80 data-[state=active]:text-primary-foreground flex items-center justify-center"
        >
          <MessageSquare className="mr-2 h-5 w-5 shrink-0" />
          Conversar
        </TabsTrigger>
        <TabsTrigger
          value="faq"
          className="text-lg py-4 data-[state=active]:bg-primary/80 data-[state=active]:text-primary-foreground flex items-center justify-center"
        >
          <HelpCircle className="mr-2 h-5 w-5 shrink-0" />
          Perguntas Frequentes
        </TabsTrigger>
      </TabsList>

      <TabsContent value="chat" className="mt-0">
        <Card className="border-2 border-primary bg-card shadow-lg text-foreground rounded-xl overflow-hidden">
          <CardHeader className="pb-4 border-b border-border bg-primary">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white shrink-0">
                <Bot className="h-7 w-7 text-primary" />
              </div>
              <div>
                <CardTitle className="text-2xl text-primary-foreground">Assistente W1</CardTitle>
                <CardDescription className="text-primary-foreground/80 text-base">
                  Tire suas dúvidas sobre o processo de constituição da sua holding patrimonial
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            <ScrollArea className="h-[450px] px-4">
              <div className="space-y-6 py-6">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"} w-full`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl p-4 ${
                        message.sender === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary text-foreground border border-border"
                      }`}
                    >
                      {message.sender === "bot" && (
                        <div className="flex items-center mb-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary mr-2 shrink-0">
                            <Bot className="h-5 w-5 text-primary-foreground" />
                          </div>
                          <span className="font-medium text-primary">Assistente W1</span>
                        </div>
                      )}
                      <p className="text-lg leading-relaxed whitespace-pre-wrap">{message.text}</p>
                      <p className="mt-2 text-sm opacity-70 text-right">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                ))}

                {/* Indicador de digitação */}
                {isLoading && (
                  <div className="flex justify-start w-full">
                    <div className="max-w-[85%] rounded-2xl p-4 bg-secondary border border-border">
                      <div className="flex items-center mb-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary mr-2 shrink-0">
                          <Bot className="h-5 w-5 text-primary-foreground" />
                        </div>
                        <span className="font-medium text-primary">Assistente W1</span>
                      </div>
                      <div className="flex items-center space-x-2 h-6">
                        <div className="h-3 w-3 rounded-full bg-primary animate-bounce" />
                        <div
                          className="h-3 w-3 rounded-full bg-primary animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        />
                        <div
                          className="h-3 w-3 rounded-full bg-primary animate-bounce"
                          style={{ animationDelay: "0.4s" }}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Mensagem de erro */}
                {error && (
                  <div className="flex justify-center w-full">
                    <div className="max-w-[85%] rounded-lg p-4 bg-destructive/10 text-destructive border border-destructive/30 text-base">
                      {error}
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
          </CardContent>

          <CardFooter className="flex items-center gap-3 p-4 border-t border-border bg-card">
            <Input
              className="text-lg py-6 px-4 bg-background border-2 border-border text-foreground placeholder:text-muted-foreground rounded-xl focus:border-primary"
              placeholder="Digite sua pergunta aqui..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSendMessage()
                }
              }}
              disabled={isLoading}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              size="lg"
              className="h-14 w-14 shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl flex items-center justify-center"
            >
              <Send className="h-6 w-6" />
              <span className="sr-only">Enviar mensagem</span>
            </Button>
          </CardFooter>
        </Card>

        {/* Guia de uso */}
        <Card className="bg-card mt-6 border border-border shadow text-foreground rounded-xl overflow-hidden">
          <div
            className="flex items-center justify-between p-4 cursor-pointer"
            onClick={() => setShowGuide(!showGuide)}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary shrink-0">
                <HelpCircle className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-medium text-foreground">Como usar o assistente</h3>
            </div>
            {showGuide ? <ChevronUp className="h-6 w-6" /> : <ChevronDown className="h-6 w-6" />}
          </div>

          {showGuide && (
            <div className="px-6 pb-6">
              <ol className="space-y-4 text-lg">
                <li className="flex items-start gap-3 bg-secondary p-4 rounded-xl">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-lg font-medium shrink-0">
                    1
                  </span>
                  <span>Digite sua pergunta no campo de texto acima ou selecione uma das perguntas frequentes.</span>
                </li>
                <li className="flex items-start gap-3 bg-secondary p-4 rounded-xl">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-lg font-medium shrink-0">
                    2
                  </span>
                  <span>Aguarde a resposta do assistente virtual inteligente.</span>
                </li>
                <li className="flex items-start gap-3 bg-secondary p-4 rounded-xl">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-lg font-medium shrink-0">
                    3
                  </span>
                  <span>Se precisar de mais informações, continue a conversa ou faça uma nova pergunta.</span>
                </li>
                <li className="flex items-start gap-3 bg-secondary p-4 rounded-xl">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-lg font-medium shrink-0">
                    4
                  </span>
                  <span>Para falar com um atendente humano, ligue para (11) 3456-7890 em horário comercial.</span>
                </li>
              </ol>
            </div>
          )}
        </Card>
      </TabsContent>

      <TabsContent value="faq" className="mt-0">
        <Card className="border-2 border-primary bg-card shadow-lg text-foreground rounded-xl overflow-hidden">
          <CardHeader className="border-b border-border bg-primary">
            <div className="flex items-center gap-3 mb-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white shrink-0">
                <HelpCircle className="h-7 w-7 text-primary" />
              </div>
              <div>
                <CardTitle className="text-2xl text-primary-foreground">Perguntas Frequentes</CardTitle>
                <CardDescription className="text-primary-foreground/80 text-base">
                  Selecione uma das perguntas abaixo para obter respostas rápidas
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="py-6">
            <div className="grid grid-cols-1 gap-4">
              {PERGUNTAS_FREQUENTES.map((pergunta) => (
                <Button
                  key={pergunta.id}
                  variant="outline"
                  className="justify-start h-auto py-5 px-5 text-lg w-full bg-background border-2 border-border hover:bg-primary/10 hover:border-primary text-foreground rounded-xl"
                  onClick={() => {
                    handleQuickQuestion(pergunta.text)
                    document
                      .querySelector('[data-value="chat"]')
                      ?.dispatchEvent(new MouseEvent("click", { bubbles: true }))
                  }}
                  disabled={isLoading}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary mr-3 shrink-0">
                        <pergunta.icon className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <span className="text-left">{pergunta.text}</span>
                    </div>
                    <ArrowRight className="h-5 w-5 ml-2 shrink-0" />
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Indicador de IA */}
      <div className="flex items-center justify-center gap-2 text-base text-muted-foreground mt-6 bg-secondary p-3 rounded-lg">
        <Bot className="h-5 w-5 text-primary shrink-0" />
        <span>Este assistente utiliza inteligência artificial para fornecer respostas personalizadas</span>
      </div>
    </Tabs>
  )
}
