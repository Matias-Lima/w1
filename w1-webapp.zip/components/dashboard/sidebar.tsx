"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Briefcase,
  CreditCard,
  FileText,
  LayoutDashboard,
  LogOut,
  Settings,
  Users,
  Home,
  Headphones,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { SafeLink } from "@/components/safe-link"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"

interface MenuItem {
  title: string
  href: string
  icon: React.ElementType
  submenu?: {
    title: string
    href: string
  }[]
}

// Modificar o array menuItems para incluir subseções no Dashboard
const menuItems: MenuItem[] = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
    submenu: [
      {
        title: "Visão Geral",
        href: "/dashboard",
      },
      {
        title: "Análise Financeira",
        href: "/dashboard/analise-financeira",
      },
      {
        title: "Mapa de Riscos",
        href: "/dashboard/mapa-riscos",
      },
    ],
  },
  {
    title: "Holding Patrimonial",
    href: "/dashboard/holding",
    icon: Briefcase,
    submenu: [
      {
        title: "Visão Geral",
        href: "/dashboard/holding",
      },
      {
        title: "Documentos",
        href: "/dashboard/holding/documentos",
      },
      {
        title: "Processo",
        href: "/dashboard/holding/etapas",
      },
    ],
  },
  {
    title: "Atendimento",
    href: "/dashboard/atendimento",
    icon: Headphones,
  },
  {
    title: "Financeiro",
    href: "/dashboard/financeiro",
    icon: BarChart3,
  },
  {
    title: "Transações",
    href: "/dashboard/transacoes",
    icon: CreditCard,
  },
  {
    title: "Relatórios",
    href: "/dashboard/relatorios",
    icon: FileText,
  },
  {
    title: "Equipe",
    href: "/dashboard/equipe",
    icon: Users,
  },
  {
    title: "Configurações",
    href: "/dashboard/configuracoes",
    icon: Settings,
  },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const { logout } = useAuth()
  const router = useRouter()

  // Evitar problemas de hidratação
  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  if (!mounted) return null

  // Função para determinar qual categoria principal está ativa
  const getActiveMainCategory = () => {
    // Ordenar do mais específico para o menos específico
    const allPaths = menuItems
      .flatMap((item) => {
        const paths = [item.href]
        if (item.submenu) {
          paths.push(...item.submenu.map((sub) => sub.href))
        }
        return paths
      })
      .sort((a, b) => b.length - a.length) // Ordena do mais longo (mais específico) para o mais curto

    // Encontrar o caminho mais específico que corresponde ao pathname atual
    const matchingPath = allPaths.find(
      (path) =>
        // Caso especial para o dashboard principal
        (path === "/dashboard" && pathname === "/dashboard") ||
        // Para outros caminhos, verificar se o pathname começa com o caminho
        (path !== "/dashboard" && pathname.startsWith(path)),
    )

    // Encontrar a categoria principal que contém este caminho
    return menuItems.findIndex(
      (item) => item.href === matchingPath || (item.submenu && item.submenu.some((sub) => sub.href === matchingPath)),
    )
  }

  const activeMainCategoryIndex = getActiveMainCategory()

  return (
    <aside className="fixed inset-y-0 left-0 z-10 hidden w-64 flex-col bg-white border-r border-border md:flex shadow-sm">
      <div className="flex h-16 items-center px-6 border-b border-border">
        <Link href="/dashboard" className="flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 72 36"
            height="36"
            width="72"
            className="mr-2"
          >
            <g clipPath="url(#clip0_2635_2144)">
              <path
                fill="#374151"
                d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
              ></path>
            </g>
            <defs>
              <clipPath id="clip0_2635_2144">
                <rect fill="white" height="36" width="72"></rect>
              </clipPath>
            </defs>
          </svg>
        </Link>
      </div>

      <div className="mt-6 px-4">
        <Link
          href="/"
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-black transition-colors rounded-lg hover:bg-gray-100"
        >
          <Home className="h-4 w-4" />
          <span>Voltar ao site</span>
        </Link>
      </div>

      <div className="mt-2 px-4">
        <h2 className="px-3 text-xs font-semibold text-black uppercase tracking-wider">Menu Principal</h2>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-1">
        {menuItems.map((item, index) => {
          // Verifica se este item principal é o ativo
          const isMainActive = index === activeMainCategoryIndex

          // Para submenus, verificamos qual subitem está ativo
          const hasSubmenu = item.submenu && item.submenu.length > 0
          const activeSubmenuIndex =
            hasSubmenu && isMainActive ? item.submenu.findIndex((subItem) => pathname.startsWith(subItem.href)) : -1

          // Verifica se o item está em construção
          const isInConstruction = [
            "/dashboard/financeiro",
            "/dashboard/transacoes",
            "/dashboard/relatorios",
            "/dashboard/equipe",
            "/dashboard/configuracoes",
          ].includes(item.href)

          return (
            <div key={item.href} className="space-y-1">
              {isInConstruction ? (
                <SafeLink
                  href={item.href}
                  inConstruction={true}
                  className={cn(
                    "flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 ease-in-out",
                    isMainActive ? "bg-primary/10 text-black font-bold" : "text-black hover:bg-gray-100",
                  )}
                >
                  <div className="flex items-center">
                    <item.icon
                      className={cn("mr-3 h-5 w-5 transition-colors", isMainActive ? "text-primary" : "text-black")}
                    />
                    <span>{item.title}</span>
                  </div>
                  {isMainActive && <div className="h-2 w-2 rounded-full bg-primary" />}
                </SafeLink>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 ease-in-out",
                    isMainActive ? "bg-primary/10 text-black font-bold" : "text-black hover:bg-gray-100",
                  )}
                >
                  <div className="flex items-center">
                    <item.icon
                      className={cn("mr-3 h-5 w-5 transition-colors", isMainActive ? "text-primary" : "text-black")}
                    />
                    <span>{item.title}</span>
                  </div>
                  {isMainActive && <div className="h-2 w-2 rounded-full bg-primary" />}
                </Link>
              )}

              {hasSubmenu && (
                <div className="ml-9 space-y-1 border-l border-gray-200 pl-2">
                  {item.submenu.map((subItem, subIndex) => {
                    // Um subitem está ativo se o item principal estiver ativo e este for o subitem ativo
                    const isSubActive = isMainActive && subIndex === activeSubmenuIndex

                    // Verifica se o subitem está em construção
                    const isSubInConstruction = subItem.href.includes("/dashboard/holding/processo")

                    return isSubInConstruction ? (
                      <SafeLink
                        key={subItem.href}
                        href={subItem.href}
                        inConstruction={false}
                        className={cn(
                          "flex items-center justify-between rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200 ease-in-out",
                          isSubActive ? "text-black font-bold" : "text-black hover:bg-gray-100",
                        )}
                      >
                        <span>{subItem.title}</span>
                        {isSubActive && <div className="h-1.5 w-1.5 rounded-full bg-primary" />}
                      </SafeLink>
                    ) : (
                      <Link
                        key={subItem.href}
                        href={subItem.href}
                        className={cn(
                          "flex items-center justify-between rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200 ease-in-out",
                          isSubActive ? "text-black font-bold" : "text-black hover:bg-gray-100",
                        )}
                      >
                        <span>{subItem.title}</span>
                        {isSubActive && <div className="h-1.5 w-1.5 rounded-full bg-primary" />}
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </nav>

      <div className="border-t border-gray-200 p-4">
        <button
          onClick={handleLogout}
          className="flex items-center justify-center gap-2 rounded-lg bg-gray-100 px-4 py-2 text-sm font-medium text-black transition-colors hover:bg-gray-200 w-full"
        >
          <LogOut className="h-4 w-4 text-black" />
          <span>Sair da conta</span>
        </button>
      </div>
    </aside>
  )
}

// Exportação adicional para compatibilidade
export const Sidebar = DashboardSidebar
