import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface CardMetricProps {
  title: string
  value: string
  description: string
  trend?: {
    value: string
    isPositive: boolean
  }
  icon: LucideIcon
  iconColor?: string
  className?: string
}

export function CardMetric({
  title,
  value,
  description,
  trend,
  icon: Icon,
  iconColor = "text-teal-400",
  className,
}: CardMetricProps) {
  return (
    <div className={cn("rounded-xl border border-gray-200 bg-white p-6 metric-card backdrop-blur-sm", className)}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-700">{title}</h3>
        <div className={`rounded-full bg-gray-100 p-2 ${iconColor} metric-icon`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <div className="mt-3">
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <p className="mt-1 text-sm text-gray-700">{description}</p>
      </div>
      {trend && (
        <div className="mt-4 flex items-center">
          <span
            className={cn(
              "text-sm font-medium flex items-center",
              trend.isPositive ? "text-emerald-500" : "text-rose-500",
            )}
          >
            <svg
              className={cn("mr-1 h-3 w-3", trend.isPositive ? "rotate-0" : "rotate-180")}
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M12 4L20 14H4L12 4Z" fill="currentColor" />
            </svg>
            {trend.isPositive ? "+" : ""}
            {trend.value}
          </span>
          <span className="ml-1 text-xs text-gray-400">vs. mês anterior</span>
        </div>
      )}
    </div>
  )
}
