"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

// Paleta de cores com ordem de prioridade ajustada
const COLORS = {
  primary: "#009E73", // Verde (principal)
  secondary: "#56B4E9", // Azul claro (secundária)
  tertiary: "#E69F00", // Laranja (terciária)
  quaternary: "#F0E442", // Amarelo (quaternária)
  quinary: "#000000", // Preto (quinta)
  senary: "#CC79A7", // Rosa (sexta)
  darkBlue: "#0072B2", // Azul escuro (alternativa)
  darkOrange: "#D55E00", // Laranja escuro (alternativa)
  gray: "#999999", // Cinza (alternativa)
}

export function AnaliseCenariosFiscais({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={className} {...props}>
      <Card className="border-gray-800 bg-gray-900 text-white hover-lift transition-all duration-300">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Análise de Cenários Fiscais</CardTitle>
          <CardDescription className="text-gray-400">Comparativo de carga tributária com e sem holding</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  {
                    categoria: "IR",
                    semHolding: 180000,
                    comHolding: 120000,
                  },
                  {
                    categoria: "ITCMD",
                    semHolding: 226000,
                    comHolding: 45000,
                  },
                  {
                    categoria: "ITBI",
                    semHolding: 90000,
                    comHolding: 45000,
                  },
                  {
                    categoria: "Outros",
                    semHolding: 65000,
                    comHolding: 40000,
                  },
                ]}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="categoria" stroke="#94A3B8" />
                <YAxis stroke="#94A3B8" tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1F2937", borderColor: "#374151", borderRadius: "0.375rem" }}
                  itemStyle={{ color: "#F9FAFB" }}
                  formatter={(value: number) => [`R$ ${value.toLocaleString()}`, ""]}
                />
                <Legend />
                <Bar dataKey="semHolding" name="Sem Holding" fill={COLORS.tertiary} />
                <Bar dataKey="comHolding" name="Com Holding" fill={COLORS.primary} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex flex-col items-center">
                <span className="text-xs text-gray-400 mb-1">Economia Total</span>
                <span className="text-2xl font-bold text-white">R$ 311.000</span>
                <Badge className="mt-2 bg-[#009E73]/20 text-[#009E73] border-[#009E73]/50">55% de redução</Badge>
              </div>
            </div>
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex flex-col items-center">
                <span className="text-xs text-gray-400 mb-1">Economia em ITCMD</span>
                <span className="text-2xl font-bold text-white">R$ 181.000</span>
                <Badge className="mt-2 bg-[#009E73]/20 text-[#009E73] border-[#009E73]/50">80% de redução</Badge>
              </div>
            </div>
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex flex-col items-center">
                <span className="text-xs text-gray-400 mb-1">Economia em IR</span>
                <span className="text-2xl font-bold text-white">R$ 60.000</span>
                <Badge className="mt-2 bg-[#009E73]/20 text-[#009E73] border-[#009E73]/50">33% de redução</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
