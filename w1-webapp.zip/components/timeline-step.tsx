import type React from "react"
import { CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { cn } from "@/lib/utils"

export type StepStatus = "completed" | "current" | "waiting" | "pending"

interface TimelineStepProps {
  icon: React.ElementType
  title: string
  description: string
  status: StepStatus
  step: number
  isLast?: boolean
  actionLink?: string
  actionText?: string
  waitingText?: string
}

export function TimelineStep({
  icon: Icon,
  title,
  description,
  status,
  step,
  isLast = false,
  actionLink = "#",
  actionText = "Acessar Etapa",
  waitingText,
}: TimelineStepProps) {
  // Definir classes baseadas no status
  const statusClasses = {
    completed: "border-teal-500 bg-teal-50 text-teal-600",
    current: "border-blue-500 bg-blue-50 text-blue-600 animate-pulse",
    waiting: "border-amber-500 bg-amber-50 text-amber-600",
    pending: "border-gray-300 bg-gray-50 text-gray-500",
  }

  const connectorClasses = {
    completed: "bg-teal-500",
    current: "bg-gradient-to-b from-teal-500 to-gray-300",
    waiting: "bg-amber-500",
    pending: "bg-gray-300",
  }

  const textClasses = {
    completed: "text-gray-800",
    current: "text-gray-900",
    waiting: "text-gray-800",
    pending: "text-gray-500",
  }

  return (
    <div className="flex timeline-step">
      <div className="flex flex-col items-center">
        <div
          className={cn(
            "flex h-10 w-10 sm:h-14 sm:w-14 items-center justify-center rounded-full border-3",
            statusClasses[status],
          )}
          aria-label={`Etapa ${step}: ${status === "completed" ? "Concluída" : status === "current" ? "Em andamento" : status === "waiting" ? "Aguardando" : "Pendente"}`}
        >
          {status === "completed" ? (
            <CheckCircle2 className="h-5 w-5 sm:h-7 sm:w-7" />
          ) : (
            <span className="text-base sm:text-xl font-bold">{step}</span>
          )}
        </div>
        {!isLast && (
          <div className={cn("h-full w-1 sm:w-1.5 timeline-connector", connectorClasses[status])} aria-hidden="true" />
        )}
      </div>

      <div className={cn("ml-3 sm:ml-6 pb-8 sm:pb-10", isLast ? "" : "mb-2")}>
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
          <div className={cn("mr-2 rounded-full p-1.5 sm:p-2", statusClasses[status])}>
            <Icon className="h-4 w-4 sm:h-6 sm:w-6" />
          </div>
          <h3 className={cn("text-base sm:text-xl font-semibold", textClasses[status])}>{title}</h3>

          {status !== "pending" && (
            <div
              className={cn(
                "mt-1 sm:mt-0 ml-0 sm:ml-4 rounded-full px-2 py-1 text-xs font-medium",
                status === "completed"
                  ? "bg-teal-100 text-teal-800"
                  : status === "current"
                    ? "bg-blue-100 text-blue-800"
                    : status === "waiting"
                      ? "bg-amber-100 text-amber-800"
                      : "bg-gray-100 text-gray-800",
              )}
            >
              {status === "completed" && "Concluído"}
              {status === "current" && "Em andamento"}
              {status === "waiting" && "Aguardando"}
              {status === "pending" && "Pendente"}
            </div>
          )}
        </div>

        <p
          className={cn(
            "mt-2 text-sm sm:text-base leading-relaxed",
            status === "pending" ? "text-gray-500" : "text-gray-700",
          )}
        >
          {description}
        </p>

        {status === "waiting" && waitingText && (
          <div className="mt-3 rounded-md bg-amber-50 p-3 border-l-2 border-amber-500">
            <p className="text-xs sm:text-sm text-amber-800">{waitingText}</p>
          </div>
        )}

        {status === "current" && (
          <div className="mt-4 space-y-2">
            <Link href={actionLink} className="block w-full sm:w-auto">
              <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm sm:text-base py-4 sm:py-6 px-4 sm:px-6 button-large">
                {actionText}
              </Button>
            </Link>
            <p className="text-xs sm:text-sm text-blue-700">Clique para continuar de onde parou</p>
          </div>
        )}

        {status === "completed" && (
          <Link href={actionLink} className="block mt-4 w-full sm:w-auto">
            <Button
              variant="outline"
              className="w-full sm:w-auto border-teal-500/30 text-teal-600 hover:bg-teal-50 hover:text-teal-700 text-sm sm:text-base py-3 sm:py-5"
              size="lg"
            >
              Ver Detalhes Completos
            </Button>
          </Link>
        )}
      </div>
    </div>
  )
}
