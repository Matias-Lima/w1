"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { AlertTriangle, Check, Info } from "lucide-react"

// Dados para o mapa de riscos
const riscosData = [
  {
    categoria: "Pessoa Física",
    subcategorias: [
      {
        nome: "Bens Imóveis em Nome Próprio",
        risco: "alto",
        impacto: "Exposição a processos judiciais e maior tributação na sucessão",
        solucao: "Transferência para holding patrimonial com proteção jurídica",
      },
      {
        nome: "Investimentos Financeiros Diretos",
        risco: "medio",
        impacto: "Tributação não otimizada e exposição a riscos pessoais",
        solucao: "Estruturação via fundos exclusivos ou holdings",
      },
      {
        nome: "Ausência de Testamento/Planejamento Sucessório",
        risco: "alto",
        impacto: "Conflitos familiares e custos elevados de inventário",
        solucao: "Implementação de protocolo familiar e estruturas societárias",
      },
    ],
  },
  {
    categoria: "Pessoa Jurídica",
    subcategorias: [
      {
        nome: "Regime Tributário Inadequado",
        risco: "alto",
        impacto: "Pagamento excessivo de impostos e perda de competitividade",
        solucao: "Análise e reestruturação do regime tributário ideal",
      },
      {
        nome: "Mistura de Patrimônio Pessoal e Empresarial",
        risco: "alto",
        impacto: "Risco de desconsideração da personalidade jurídica",
        solucao: "Segregação patrimonial e governança corporativa",
      },
      {
        nome: "Distribuição de Lucros sem Planejamento",
        risco: "medio",
        impacto: "Tributação excessiva e ineficiência fiscal",
        solucao: "Estratégia de distribuição otimizada e estruturação societária",
      },
    ],
  },
  {
    categoria: "Investimentos",
    subcategorias: [
      {
        nome: "Diversificação Inadequada",
        risco: "medio",
        impacto: "Exposição excessiva a riscos específicos de mercado",
        solucao: "Estratégia de alocação diversificada com eficiência fiscal",
      },
      {
        nome: "Estrutura de Custos Elevada",
        risco: "baixo",
        impacto: "Redução da rentabilidade líquida dos investimentos",
        solucao: "Otimização da estrutura de investimentos e custos",
      },
      {
        nome: "Investimentos Internacionais sem Proteção",
        risco: "alto",
        impacto: "Exposição a dupla tributação e riscos regulatórios",
        solucao: "Estruturação internacional com proteção tributária",
      },
    ],
  },
]

// Componente para cada item de risco
function RiscoItem({ item, isVisible }: { item: any; isVisible: boolean }) {
  const [expanded, setExpanded] = useState(false)

  // Definir cor com base no nível de risco
  const getRiscoColor = (risco: string) => {
    switch (risco) {
      case "alto":
        return "bg-rose-500"
      case "medio":
        return "bg-amber-500"
      case "baixo":
        return "bg-emerald-500"
      default:
        return "bg-gray-500"
    }
  }

  // Definir ícone com base no nível de risco
  const getRiscoIcon = (risco: string) => {
    switch (risco) {
      case "alto":
        return <AlertTriangle className="h-4 w-4" />
      case "medio":
        return <Info className="h-4 w-4" />
      case "baixo":
        return <Check className="h-4 w-4" />
      default:
        return <Info className="h-4 w-4" />
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
      transition={{ duration: 0.5 }}
      className="mb-4"
    >
      <div
        className={`p-4 rounded-lg border ${expanded ? "bg-gray-50 border-gray-200" : "bg-white border-gray-100"} cursor-pointer transition-all duration-300`}
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`flex items-center justify-center h-8 w-8 rounded-full ${getRiscoColor(item.risco)} text-white`}
            >
              {getRiscoIcon(item.risco)}
            </div>
            <h4 className="font-medium text-gray-900">{item.nome}</h4>
          </div>
          <div className="flex items-center">
            <span
              className={`text-xs font-medium px-2 py-1 rounded-full ${
                item.risco === "alto"
                  ? "bg-rose-100 text-rose-700"
                  : item.risco === "medio"
                    ? "bg-amber-100 text-amber-700"
                    : "bg-emerald-100 text-emerald-700"
              }`}
            >
              Risco {item.risco}
            </span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className={`h-5 w-5 ml-2 text-gray-600 transition-transform duration-300 ${expanded ? "rotate-180" : ""}`}
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>

        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.3 }}
            className="mt-4 pt-4 border-t border-gray-200"
          >
            <div className="space-y-3">
              <div>
                <h5 className="text-sm font-medium text-gray-800">Impacto</h5>
                <p className="text-sm text-gray-700">{item.impacto}</p>
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-800">Solução W1</h5>
                <p className="text-sm text-teal-700">{item.solucao}</p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  )
}

export function MapaRiscosFiscais() {
  const [activeCategory, setActiveCategory] = useState("Pessoa Física")
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  return (
    <div ref={ref} className="w-full">
      <div className="flex flex-wrap gap-2 mb-6">
        {riscosData.map((categoria) => (
          <button
            key={categoria.categoria}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeCategory === categoria.categoria
                ? "bg-teal-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
            onClick={() => setActiveCategory(categoria.categoria)}
          >
            {categoria.categoria}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {riscosData
          .find((cat) => cat.categoria === activeCategory)
          ?.subcategorias.map((item, index) => (
            <RiscoItem key={item.nome} item={item} isVisible={inView} />
          ))}
      </div>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <div className="flex items-start gap-3">
          <div className="rounded-full bg-teal-50 p-2 text-teal-600 mt-1">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
            </svg>
          </div>
          <div>
            <h4 className="font-medium text-gray-900">Avaliação de Risco Personalizada</h4>
            <p className="text-sm text-gray-700 mt-1">
              Este mapa apresenta os riscos fiscais mais comuns. Para uma análise detalhada do seu patrimônio
              específico, agende uma consulta com nossos especialistas.
            </p>
            <button className="mt-3 text-sm font-medium text-teal-600 hover:text-teal-700 transition-colors">
              Solicitar avaliação personalizada →
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
