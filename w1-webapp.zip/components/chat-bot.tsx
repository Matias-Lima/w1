"use client"

import { useState, useRef, useEffect } from "react"
import { Send, X, Maximize2, Minimize2, MessageSquare, HelpCircle, Bot } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

type QuickReply = {
  id: string
  text: string
}

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Olá! Sou o assistente virtual da W1. Como posso ajudar você hoje?",
      role: "assistant",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [showHelp, setShowHelp] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const quickReplies: QuickReply[] = [
    { id: "q1", text: "Como a W1 pode me ajudar?" },
    { id: "q2", text: "Quais os benefícios da holding?" },
    { id: "q3", text: "Preciso de ajuda com planejamento tributário" },
  ]

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  useEffect(() => {
    // Abrir o chat automaticamente após 3 segundos
    const timer = setTimeout(() => {
      setIsOpen(true)
    }, 3000)

    return () => clearTimeout(timer)
  }, [])

  const handleSendMessage = async (content: string) => {
    if (!content.trim() || isTyping) return

    // Adicionar mensagem do usuário
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    }

    // Atualizar mensagens com a mensagem do usuário
    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    try {
      // Preparar mensagens para a API no formato correto
      const apiMessages = messages.concat(userMessage).map((msg) => ({
        role: msg.role === "user" ? "user" : "assistant",
        content: msg.content,
      }))

      // Fazer a chamada para a API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: apiMessages,
        }),
      })

      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`)
      }

      const data = await response.json()

      // Verificar se a resposta contém o campo esperado
      if (!data.response) {
        throw new Error("Formato de resposta inválido")
      }

      // Adicionar resposta do assistente
      const assistantMessage: Message = {
        id: Date.now().toString(),
        content: data.response,
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Erro ao processar mensagem:", error)

      // Adicionar mensagem de erro como resposta do assistente
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente mais tarde.",
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsTyping(false)
    }
  }

  const handleQuickReply = (reply: QuickReply) => {
    handleSendMessage(reply.text)
  }

  const toggleChat = () => {
    setIsOpen(!isOpen)
    setIsMinimized(false)
    if (!isOpen && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus()
      }, 100)
    }
  }

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized)
  }

  const toggleHelp = () => {
    setShowHelp(!showHelp)
  }

  return (
    <>
      {/* Botão flutuante para abrir o chat quando fechado */}
      {!isOpen && (
        <button
          onClick={toggleChat}
          className="fixed bottom-6 right-6 z-50 flex h-16 w-16 items-center justify-center rounded-full bg-teal-500 text-white shadow-lg transition-all hover:bg-teal-400 focus:outline-none focus:ring-4 focus:ring-teal-300"
          aria-label="Abrir chat com assistente virtual"
        >
          <MessageSquare className="h-7 w-7" />
        </button>
      )}

      {/* Container do chat */}
      <div
        className={cn(
          "fixed bottom-6 right-6 z-50 w-[350px] md:w-[400px] transition-all duration-300 transform",
          isOpen ? "translate-y-0 opacity-100" : "translate-y-12 opacity-0 pointer-events-none",
          isMinimized ? "h-auto" : "h-[550px] md:h-[600px]",
        )}
      >
        <Card className="flex h-full flex-col overflow-hidden border-2 border-teal-600 bg-gray-50 text-gray-900 shadow-xl rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 border-b border-gray-200 bg-teal-500 px-4 py-4">
            <div className="flex items-center space-x-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white">
                <Bot className="h-6 w-6 text-teal-600" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-gray-900">Assistente W1</h3>
                <p className="text-xs text-teal-100">Estamos aqui para ajudar</p>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-full text-gray-900 hover:bg-teal-100 focus:ring-2 focus:ring-white"
                onClick={toggleHelp}
                aria-label="Ajuda"
              >
                <HelpCircle className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-full text-gray-900 hover:bg-teal-100 focus:ring-2 focus:ring-white"
                onClick={toggleMinimize}
                aria-label={isMinimized ? "Maximizar chat" : "Minimizar chat"}
              >
                {isMinimized ? <Maximize2 className="h-5 w-5" /> : <Minimize2 className="h-5 w-5" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-full text-gray-900 hover:bg-teal-100 focus:ring-2 focus:ring-white"
                onClick={toggleChat}
                aria-label="Fechar chat"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </CardHeader>

          {!isMinimized && (
            <>
              {showHelp ? (
                <div className="flex-1 overflow-y-auto p-6 bg-gray-100">
                  <div className="space-y-6">
                    <div className="text-center">
                      <h3 className="text-xl font-bold text-teal-600 mb-2">Como usar o assistente</h3>
                      <p className="text-gray-700">Aqui estão algumas dicas para usar nosso assistente virtual</p>
                    </div>

                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-teal-500 text-lg mb-2">1. Faça perguntas simples</h4>
                        <p className="text-gray-700">
                          Digite suas dúvidas de forma clara e direta para obter as melhores respostas.
                        </p>
                      </div>

                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-teal-500 text-lg mb-2">2. Use os botões rápidos</h4>
                        <p className="text-gray-700">Clique nos botões abaixo da conversa para perguntas frequentes.</p>
                      </div>

                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-teal-500 text-lg mb-2">3. Aguarde as respostas</h4>
                        <p className="text-gray-700">
                          Nosso assistente pode levar alguns segundos para responder suas perguntas.
                        </p>
                      </div>
                    </div>

                    <Button
                      className="w-full bg-teal-600 hover:bg-teal-700 text-white py-6 text-lg rounded-lg"
                      onClick={toggleHelp}
                    >
                      Voltar para o chat
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <CardContent className="flex-1 overflow-y-auto p-4 bg-gray-100">
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={cn(
                            "flex w-max max-w-[85%] flex-col rounded-lg px-4 py-3 text-base",
                            message.role === "user"
                              ? "ml-auto bg-teal-600 text-white"
                              : "bg-white text-gray-900 border border-gray-200",
                          )}
                        >
                          {message.content}
                        </div>
                      ))}
                      {isTyping && (
                        <div className="flex w-max max-w-[85%] flex-col rounded-lg bg-white border border-gray-200 px-4 py-3 text-base text-gray-900">
                          <div className="flex space-x-2">
                            <div className="h-3 w-3 animate-bounce rounded-full bg-teal-400"></div>
                            <div
                              className="h-3 w-3 animate-bounce rounded-full bg-teal-400"
                              style={{ animationDelay: "0.2s" }}
                            ></div>
                            <div
                              className="h-3 w-3 animate-bounce rounded-full bg-teal-400"
                              style={{ animationDelay: "0.4s" }}
                            ></div>
                          </div>
                        </div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  </CardContent>

                  <div className="border-t border-gray-200 px-4 py-3 bg-gray-100">
                    <p className="text-sm text-gray-700 mb-2">Perguntas frequentes:</p>
                    <div className="flex flex-wrap gap-2">
                      {quickReplies.map((reply) => (
                        <button
                          key={reply.id}
                          onClick={() => handleQuickReply(reply)}
                          className="rounded-full border-2 border-teal-500 bg-white px-4 py-2 text-sm text-gray-900 hover:bg-teal-100 focus:outline-none focus:ring-2 focus:ring-teal-400"
                          disabled={isTyping}
                        >
                          {reply.text}
                        </button>
                      ))}
                    </div>
                  </div>

                  <CardFooter className="border-t border-gray-200 p-3 bg-gray-100">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault()
                        handleSendMessage(inputValue)
                      }}
                      className="flex w-full items-center space-x-2"
                    >
                      <Input
                        ref={inputRef}
                        type="text"
                        placeholder="Digite sua pergunta aqui..."
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        className="flex-1 rounded-full border-2 border-gray-300 bg-white px-4 py-3 text-base text-gray-900 placeholder:text-gray-500 focus:border-teal-500 focus:outline-none"
                        disabled={isTyping}
                      />
                      <Button
                        type="submit"
                        size="icon"
                        className="h-12 w-12 rounded-full bg-teal-600 text-white hover:bg-teal-700 focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 focus:ring-offset-gray-100"
                        disabled={!inputValue.trim() || isTyping}
                      >
                        <Send className="h-5 w-5" />
                        <span className="sr-only">Enviar mensagem</span>
                      </Button>
                    </form>
                  </CardFooter>
                </>
              )}
            </>
          )}
        </Card>
      </div>
    </>
  )
}
