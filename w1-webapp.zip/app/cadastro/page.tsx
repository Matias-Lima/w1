"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Eye, EyeOff, Loader2 } from "lucide-react"
import { z } from "zod"
import { useAuth } from "@/lib/auth-context"
import { Alert, AlertDescription } from "@/components/ui/alert"

const cadastroSchema = z
  .object({
    nome: z.string().min(3, { message: "O nome deve ter pelo menos 3 caracteres" }),
    email: z.string().email({ message: "Email inválido" }),
    password: z.string().min(6, { message: "A senha deve ter pelo menos 6 caracteres" }),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "As senhas não coincidem",
    path: ["confirmPassword"],
  })

export default function CadastroPage() {
  const router = useRouter()
  const { register, isLoading } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    password: "",
    confirmPassword: "",
    termos: false,
  })
  const [errors, setErrors] = useState<{
    nome?: string
    email?: string
    password?: string
    confirmPassword?: string
    termos?: string
    general?: string
  }>({})
  const [successMessage, setSuccessMessage] = useState<string | null>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Limpar erro quando o usuário começa a digitar
    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }))
    }
  }

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, termos: checked }))
    if (errors.termos) {
      setErrors((prev) => ({ ...prev, termos: undefined }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSuccessMessage(null)

    // Verificar se os termos foram aceitos
    if (!formData.termos) {
      setErrors((prev) => ({
        ...prev,
        termos: "Você precisa aceitar os termos para continuar",
      }))
      return
    }

    try {
      // Validar dados do formulário
      cadastroSchema.parse({
        nome: formData.nome,
        email: formData.email,
        password: formData.password,
        confirmPassword: formData.confirmPassword,
      })

      // Resetar erros
      setErrors({})

      // Registrar o usuário
      const result = await register(formData.nome, formData.email, formData.password)

      if (result.success) {
        setSuccessMessage("Conta criada com sucesso! Redirecionando para o dashboard...")

        // Redirecionar para o dashboard após um breve delay
        setTimeout(() => {
          router.push("/dashboard")
        }, 1500)
      } else {
        setErrors({
          general: result.message || "Erro ao criar conta. Tente novamente.",
        })
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Mapear erros de validação
        const formattedErrors: { [key: string]: string } = {}
        error.errors.forEach((err) => {
          if (err.path[0]) {
            formattedErrors[err.path[0] as string] = err.message
          }
        })
        setErrors(formattedErrors)
      } else {
        setErrors({
          general: "Ocorreu um erro inesperado. Tente novamente.",
        })
      }
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-white text-gray-900">
      {/* Header */}
      <header className="w-full border-b border-gray-200 bg-white py-4">
        <div className="container flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 72 36"
              height="36"
              width="72"
              className="mr-2"
            >
              <g clipPath="url(#clip0_2635_2144)">
                <path
                  fill="#0A1017"
                  d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
                ></path>
              </g>
              <defs>
                <clipPath id="clip0_2635_2144">
                  <rect fill="white" height="36" width="72"></rect>
                </clipPath>
              </defs>
            </svg>
          </Link>
          <Link href="/login" className="flex items-center text-sm text-gray-600 hover:text-teal-600 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para o login
          </Link>
        </div>
      </header>

      <main className="flex flex-1 items-center justify-center px-4 py-12 relative overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-10">
          <Image src="/abstract-pattern-dark.png" alt="Background pattern" fill className="object-cover" />
        </div>

        <div className="w-full max-w-md z-10">
          <div className="rounded-xl border border-gray-200 bg-white p-8 shadow-sm">
            <div className="mb-8 text-center">
              <h1 className="text-2xl font-bold tracking-tight text-gray-900">Criar uma conta</h1>
              <p className="mt-2 text-sm text-gray-600">Preencha os dados abaixo para criar sua conta</p>
            </div>

            {successMessage && (
              <Alert className="mb-6 bg-green-50 border-green-200 text-green-800">
                <AlertDescription>{successMessage}</AlertDescription>
              </Alert>
            )}

            {errors.general && (
              <Alert className="mb-6 bg-red-50 border-red-200 text-red-800">
                <AlertDescription>{errors.general}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="nome" className="text-gray-700">
                  Nome completo
                </Label>
                <Input
                  id="nome"
                  name="nome"
                  type="text"
                  placeholder="Seu nome completo"
                  value={formData.nome}
                  onChange={handleChange}
                  className={`bg-white border-gray-300 text-gray-900 placeholder:text-gray-500 ${
                    errors.nome ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-teal-500"
                  }`}
                  disabled={isLoading}
                  required
                />
                {errors.nome && <p className="text-xs text-red-600 mt-1">{errors.nome}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700">
                  Email
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  className={`bg-white border-gray-300 text-gray-900 placeholder:text-gray-500 ${
                    errors.email ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-teal-500"
                  }`}
                  disabled={isLoading}
                  required
                />
                {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700">
                  Senha
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleChange}
                    className={`bg-white border-gray-300 text-gray-900 placeholder:text-gray-500 ${
                      errors.password ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-teal-500"
                    }`}
                    disabled={isLoading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-900"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    <span className="sr-only">{showPassword ? "Esconder senha" : "Mostrar senha"}</span>
                  </button>
                </div>
                {errors.password && <p className="text-xs text-red-600 mt-1">{errors.password}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-gray-700">
                  Confirmar senha
                </Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className={`bg-white border-gray-300 text-gray-900 placeholder:text-gray-500 ${
                      errors.confirmPassword
                        ? "border-red-500 focus-visible:ring-red-500"
                        : "focus-visible:ring-teal-500"
                    }`}
                    disabled={isLoading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-900"
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    <span className="sr-only">{showConfirmPassword ? "Esconder senha" : "Mostrar senha"}</span>
                  </button>
                </div>
                {errors.confirmPassword && <p className="text-xs text-red-600 mt-1">{errors.confirmPassword}</p>}
              </div>

              <div className="space-y-2">
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="termos"
                    checked={formData.termos}
                    onCheckedChange={handleCheckboxChange}
                    disabled={isLoading}
                    className="mt-1 border-gray-400 data-[state=checked]:bg-teal-500 data-[state=checked]:border-teal-500"
                  />
                  <label htmlFor="termos" className="text-sm text-gray-700">
                    Eu concordo com os{" "}
                    <Link href="#" className="text-teal-600 hover:underline">
                      Termos de Serviço
                    </Link>{" "}
                    e{" "}
                    <Link href="#" className="text-teal-600 hover:underline">
                      Política de Privacidade
                    </Link>
                  </label>
                </div>
                {errors.termos && <p className="text-xs text-red-600 mt-1">{errors.termos}</p>}
              </div>

              <Button
                type="submit"
                className="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando conta...
                  </>
                ) : (
                  "Criar conta"
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm">
              <p className="text-gray-600">
                Já tem uma conta?{" "}
                <Link href="/login" className="text-teal-600 hover:underline">
                  Faça login
                </Link>
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
