"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Eye, EyeOff, Loader2 } from "lucide-react"
import { z } from "zod"

const loginSchema = z.object({
  email: z.string().email({ message: "Email inválido" }),
  password: z.string().min(1, { message: "A senha é obrigatória" }),
})

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const callbackUrl = searchParams.get("callbackUrl") || "/dashboard"
  const { login, isLoading: authLoading } = useAuth()

  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    remember: false,
  })
  const [errors, setErrors] = useState<{
    email?: string
    password?: string
    auth?: string
  }>({})

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Limpar erro quando o usuário começa a digitar
    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }))
    }
  }

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, remember: checked }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      // Validar dados do formulário
      loginSchema.parse({
        email: formData.email,
        password: formData.password,
      })

      // Resetar erros
      setErrors({})

      // Iniciar processo de login
      setIsLoading(true)

      // Chamar a função de login
      const success = await login(formData.email, formData.password)

      if (success) {
        // Redirecionar para o dashboard após login bem-sucedido
        router.push(callbackUrl)
      } else {
        setErrors({
          auth: "Credenciais inválidas. Verifique seu email e senha.",
        })
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Mapear erros de validação
        const formattedErrors: { [key: string]: string } = {}
        error.errors.forEach((err) => {
          if (err.path[0]) {
            formattedErrors[err.path[0] as string] = err.message
          }
        })
        setErrors(formattedErrors)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-white text-gray-900">
      {/* Header */}
      <header className="w-full border-b border-gray-200 bg-white py-4">
        <div className="container flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 72 36"
              height="36"
              width="72"
              className="mr-2"
            >
              <g clipPath="url(#clip0_2635_2144)">
                <path
                  fill="#0A1017"
                  d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
                ></path>
              </g>
              <defs>
                <clipPath id="clip0_2635_2144">
                  <rect fill="white" height="36" width="72"></rect>
                </clipPath>
              </defs>
            </svg>
          </Link>
        </div>
      </header>

      <main className="flex flex-1 items-center justify-center px-4 py-12 relative overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-10">
          <Image src="/abstract-pattern-dark.png" alt="Background pattern" fill className="object-cover" />
        </div>

        <div className="w-full max-w-md z-10">
          <div className="rounded-xl border border-gray-200 bg-white p-8 shadow-sm">
            <div className="mb-8 text-center">
              <h1 className="text-2xl font-bold tracking-tight text-gray-900">Entrar na sua conta</h1>
              <p className="mt-2 text-sm text-gray-600">Bem-vindo de volta! Por favor, entre com suas credenciais.</p>
            </div>

            {errors.auth && (
              <div className="mb-6 rounded-md bg-red-50 p-4 text-sm text-red-600">
                <p>{errors.auth}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700">
                  Email
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  className={`bg-white border-gray-300 text-gray-900 placeholder:text-gray-500 ${
                    errors.email ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-teal-500"
                  }`}
                  disabled={isLoading || authLoading}
                  required
                />
                {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-gray-700">
                    Senha
                  </Label>
                  <Link href="/recuperar-senha" className="text-xs text-teal-600 hover:underline">
                    Esqueceu a senha?
                  </Link>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleChange}
                    className={`bg-white border-gray-300 text-gray-900 placeholder:text-gray-500 ${
                      errors.password ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-teal-500"
                    }`}
                    disabled={isLoading || authLoading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-900"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    <span className="sr-only">{showPassword ? "Esconder senha" : "Mostrar senha"}</span>
                  </button>
                </div>
                {errors.password && <p className="text-xs text-red-600 mt-1">{errors.password}</p>}
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={formData.remember}
                  onCheckedChange={handleCheckboxChange}
                  disabled={isLoading || authLoading}
                  className="border-gray-400 data-[state=checked]:bg-teal-500 data-[state=checked]:border-teal-500"
                />
                <label htmlFor="remember" className="text-sm text-gray-700">
                  Lembrar de mim
                </label>
              </div>

              <Button
                type="submit"
                className="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium"
                disabled={isLoading || authLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  "Entrar"
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm">
              <p className="text-gray-600">
                Não tem uma conta?{" "}
                <Link href="/cadastro" className="text-teal-600 hover:underline">
                  Cadastre-se
                </Link>
              </p>
            </div>

            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-600 mb-2">Credenciais de teste:</p>
              <p className="text-xs text-gray-600">Admin: admin@w1.com.br / password</p>
              <p className="text-xs text-gray-600">Cliente: cliente@exemplo.com / password</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
