"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, ChevronRight, Shield, Puzzle, BarChart3, ArrowUpRight } from "lucide-react"
import { EconomiaRealChart } from "@/components/ecossistema/economia-real-chart"
import { MapaRiscosFiscais } from "@/components/ecossistema/mapa-riscos-fiscais"

export default function EcossistemaPage() {
  const [activeTab, setActiveTab] = useState("visao-geral")

  return (
    <div className="flex min-h-screen flex-col bg-white">
      {/* Header - Reutilizando o header principal */}
      <header className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 72 36"
                height="36"
                width="72"
                className="mr-2"
              >
                <g clipPath="url(#clip0_2635_2144)">
                  <path
                    fill="#000000"
                    d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
                  ></path>
                </g>
                <defs>
                  <clipPath id="clip0_2635_2144">
                    <rect fill="white" height="36" width="72"></rect>
                  </clipPath>
                </defs>
              </svg>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/ecossistema" className="text-sm font-medium text-teal-600 transition-colors">
              Nosso ecossistema
            </Link>
            <Link href="/" className="text-sm font-medium text-gray-700 hover:text-teal-600 transition-colors">
              Carreiras
            </Link>
            <Link href="/" className="text-sm font-medium text-gray-700 hover:text-teal-600 transition-colors">
              Sobre nós
            </Link>
            <Link href="/" className="text-sm font-medium text-gray-700 hover:text-teal-600 transition-colors">
              Atendimento
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              className="hidden md:flex bg-transparent border-teal-600/30 text-teal-600 hover:bg-teal-50 hover:text-teal-700"
              asChild
            >
              <Link href="/login">Entrar</Link>
            </Button>
            <Button className="hidden md:flex bg-teal-600 hover:bg-teal-700 text-white" asChild>
              <Link href="/cadastro">Começar agora</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-white relative overflow-hidden">
          <div className="container px-4 md:px-6 relative z-10">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-teal-50 px-3 py-1 text-sm text-teal-600">Ecossistema W1</div>
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl text-gray-900">
                  Soluções integradas para <span className="text-teal-600">otimização patrimonial</span>
                </h1>
                <p className="max-w-[600px] text-gray-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Conheça como nosso ecossistema de soluções trabalha em conjunto para proteger e otimizar seu
                  patrimônio.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row pt-4">
                  <Button className="bg-teal-600 hover:bg-teal-700 text-white group" asChild>
                    <Link href="/cadastro">
                      <span>Fale com um especialista</span>
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="mx-auto lg:ml-auto relative">
                <div className="relative rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/dark-dashboard.png"
                    alt="Ecossistema W1"
                    width={500}
                    height={400}
                    className="rounded-lg object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-gray-100/80 via-gray-100/50 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex flex-wrap gap-2">
                      <span className="inline-flex items-center rounded-full bg-teal-100 px-2.5 py-0.5 text-xs font-medium text-teal-700">
                        Otimização Fiscal
                      </span>
                      <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-700">
                        Sucessão Patrimonial
                      </span>
                      <span className="inline-flex items-center rounded-full bg-violet-100 px-2.5 py-0.5 text-xs font-medium text-violet-700">
                        Proteção de Ativos
                      </span>
                    </div>
                  </div>
                </div>
                <div className="absolute -bottom-4 -right-4 bg-teal-600 rounded-lg p-3 shadow-lg">
                  <ArrowUpRight className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Tabs Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-10">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-teal-50 px-3 py-1 text-sm text-teal-600">
                  Benefícios Exclusivos
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-gray-900">
                  Como a W1 transforma sua gestão patrimonial
                </h2>
                <p className="max-w-[900px] text-gray-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Explore os benefícios tangíveis que nossos clientes obtêm ao utilizar nossas soluções integradas.
                </p>
              </div>
            </div>

            <Tabs defaultValue="visao-geral" className="w-full" onValueChange={setActiveTab}>
              <div className="flex justify-center mb-8">
                <TabsList className="bg-gray-100 p-1">
                  <TabsTrigger
                    value="visao-geral"
                    className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
                  >
                    Visão Geral
                  </TabsTrigger>
                  <TabsTrigger
                    value="economia-real"
                    className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
                  >
                    Economia Real
                  </TabsTrigger>
                  <TabsTrigger
                    value="mapa-riscos"
                    className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
                  >
                    Mapa de Riscos
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="visao-geral" className="mt-0">
                <div className="grid gap-6 md:grid-cols-3">
                  <Card className="bg-white border-gray-200 text-gray-900 hover-lift transition-all duration-300">
                    <CardHeader className="pb-2">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-teal-50 mb-4">
                        <Shield className="h-6 w-6 text-teal-600" />
                      </div>
                      <CardTitle className="text-xl">Proteção Patrimonial</CardTitle>
                      <CardDescription className="text-gray-600">
                        Estruturas jurídicas que protegem seu patrimônio de riscos externos
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-gray-700">
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Blindagem contra processos judiciais</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Separação de patrimônio pessoal e empresarial</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Estruturas societárias otimizadas</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-white border-gray-200 text-gray-900 hover-lift transition-all duration-300">
                    <CardHeader className="pb-2">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-teal-50 mb-4">
                        <BarChart3 className="h-6 w-6 text-teal-600" />
                      </div>
                      <CardTitle className="text-xl">Otimização Fiscal</CardTitle>
                      <CardDescription className="text-gray-600">
                        Estratégias legais para redução da carga tributária
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-gray-700">
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Redução de até 15% na carga tributária anual</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Planejamento tributário personalizado</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Economia em impostos sobre sucessão</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-white border-gray-200 text-gray-900 hover-lift transition-all duration-300">
                    <CardHeader className="pb-2">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-teal-50 mb-4">
                        <Puzzle className="h-6 w-6 text-teal-600" />
                      </div>
                      <CardTitle className="text-xl">Sucessão Planejada</CardTitle>
                      <CardDescription className="text-gray-600">
                        Transferência de patrimônio entre gerações de forma eficiente
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-gray-700">
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Redução de até 80% em custos de inventário</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Transferência patrimonial sem burocracia</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-teal-600 shrink-0 mr-1" />
                          <span>Preservação do legado familiar</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="economia-real" className="mt-0">
                <Card className="bg-white border-gray-200 text-gray-900">
                  <CardHeader>
                    <CardTitle className="text-2xl">Economia Real em Números</CardTitle>
                    <CardDescription className="text-gray-600">
                      Dados reais de economia fiscal obtida por nossos clientes em diferentes cenários
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-end mb-4">
                      <div className="flex items-center gap-2 text-sm">
                        <div className="flex items-center">
                          <div className="h-3 w-3 rounded-full bg-rose-500 mr-1"></div>
                          <span className="text-gray-700">Sem W1</span>
                        </div>
                        <div className="flex items-center ml-4">
                          <div className="h-3 w-3 rounded-full bg-teal-500 mr-1"></div>
                          <span className="text-gray-700">Com W1</span>
                        </div>
                      </div>
                    </div>
                    <EconomiaRealChart />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="mapa-riscos" className="mt-0">
                <Card className="bg-white border-gray-200 text-gray-900">
                  <CardHeader>
                    <CardTitle className="text-2xl">Mapa de Riscos Fiscais</CardTitle>
                    <CardDescription className="text-gray-600">
                      Identificação visual das áreas de maior risco fiscal no seu patrimônio
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-end mb-4">
                      <div className="flex items-center gap-6 text-sm">
                        <div className="flex items-center">
                          <div className="h-3 w-3 rounded-full bg-rose-500 mr-1"></div>
                          <span className="text-gray-700">Alto Risco</span>
                        </div>
                        <div className="flex items-center">
                          <div className="h-3 w-3 rounded-full bg-amber-500 mr-1"></div>
                          <span className="text-gray-700">Médio Risco</span>
                        </div>
                        <div className="flex items-center">
                          <div className="h-3 w-3 rounded-full bg-emerald-500 mr-1"></div>
                          <span className="text-gray-700">Baixo Risco</span>
                        </div>
                      </div>
                    </div>
                    <MapaRiscosFiscais />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-white relative overflow-hidden">
          <div className="container px-4 md:px-6 text-center relative z-10">
            <div className="mx-auto max-w-3xl space-y-4">
              <h2 className="text-3xl font-bold tracking-tighter text-gray-900 sm:text-4xl md:text-5xl">
                Pronto para otimizar seu patrimônio?
              </h2>
              <p className="text-gray-700 md:text-xl/relaxed">
                Agende uma consulta gratuita e descubra como a W1 pode ajudar a proteger e otimizar seu patrimônio.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row justify-center pt-4">
                <Button className="bg-teal-600 hover:bg-teal-700 text-white group" asChild>
                  <Link href="/cadastro">
                    <span>Fale com um especialista</span>
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer - Reutilizando o footer principal */}
      <footer className="w-full border-t border-gray-200 bg-white py-12">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 lg:grid-cols-5">
            <div className="lg:col-span-2">
              <Link href="/" className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 72 36"
                  height="36"
                  width="72"
                  className="mr-2"
                >
                  <g clipPath="url(#clip0_2635_2144)">
                    <path
                      fill="#000000"
                      d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
                    ></path>
                  </g>
                  <defs>
                    <clipPath id="clip0_2635_2144">
                      <rect fill="white" height="36" width="72"></rect>
                    </clipPath>
                  </defs>
                </svg>
              </Link>
              <p className="mt-4 text-gray-600">
                Soluções completas para gestão financeira, contábil e fiscal. Simplifique processos e tome decisões mais
                inteligentes.
              </p>
              <div className="mt-6 flex gap-4">
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  <span className="sr-only">Facebook</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  <span className="sr-only">Twitter</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                  </svg>
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  <span className="sr-only">LinkedIn</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect width="4" height="12" x="2" y="9"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                </Link>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Soluções</h3>
              <nav className="mt-4 flex flex-col space-y-2">
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Gestão Financeira
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Contabilidade Digital
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Compliance Fiscal
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Integrações
                </Link>
              </nav>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Empresa</h3>
              <nav className="mt-4 flex flex-col space-y-2">
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Sobre nós
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Carreiras
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Blog
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Imprensa
                </Link>
              </nav>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Suporte</h3>
              <nav className="mt-4 flex flex-col space-y-2">
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Central de Ajuda
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Documentação
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Status
                </Link>
                <Link href="#" className="text-gray-600 hover:text-teal-600">
                  Contato
                </Link>
              </nav>
            </div>
          </div>
          <div className="mt-12 border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-600">
              &copy; {new Date().getFullYear()} W1 Tecnologia. Todos os direitos reservados.
            </p>
            <div className="mt-4 md:mt-0 flex gap-4">
              <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                Termos de Serviço
              </Link>
              <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                Política de Privacidade
              </Link>
              <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
