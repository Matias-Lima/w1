"use client"

import { useState, useEffect } from "react"
import { MapaRiscosDetalhado } from "@/components/dashboard/mapa-riscos-detalhado"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Download, Filter, PlusCircle } from "lucide-react"

export default function MapaRiscosPage() {
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratação
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col gap-2">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-800">Mapa de Riscos</h1>
            <p className="text-gray-600 mt-1">Análise detalhada de riscos fiscais, societários e sucessórios</p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-800"
            >
              <Filter className="mr-2 h-4 w-4 text-gray-500" />
              Filtrar
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-800"
            >
              <Calendar className="mr-2 h-4 w-4 text-gray-500" />
              Período
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-800"
            >
              <Download className="mr-2 h-4 w-4 text-gray-500" />
              Exportar
            </Button>
            <Button
              size="sm"
              className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white font-medium"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Novo Risco
            </Button>
          </div>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-1">
        <Card className="border-gray-200 bg-white text-gray-800 hover-lift transition-all duration-300 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Resumo de Riscos</CardTitle>
            <CardDescription className="text-gray-600">Visão geral dos riscos identificados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 overflow-hidden">
                <div className="flex flex-col items-center">
                  <span className="text-xs text-gray-500 mb-1">Total de Riscos</span>
                  <span className="text-2xl font-bold text-gray-800">24</span>
                  <div className="mt-2 flex gap-2 flex-wrap">
                    <Badge className="bg-rose-100 text-rose-700 border-rose-200">8 Críticos</Badge>
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200">10 Médios</Badge>
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">6 Baixos</Badge>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 overflow-hidden">
                <div className="flex flex-col items-center">
                  <span className="text-xs text-gray-500 mb-1">Riscos Tributários</span>
                  <span className="text-2xl font-bold text-gray-800">9</span>
                  <div className="mt-2 flex gap-2 flex-wrap">
                    <Badge className="bg-rose-100 text-rose-700 border-rose-200">4 Críticos</Badge>
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200">3 Médios</Badge>
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">2 Baixos</Badge>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 overflow-hidden">
                <div className="flex flex-col items-center">
                  <span className="text-xs text-gray-500 mb-1">Riscos Sucessórios</span>
                  <span className="text-2xl font-bold text-gray-800">7</span>
                  <div className="mt-2 flex gap-2 flex-wrap">
                    <Badge className="bg-rose-100 text-rose-700 border-rose-200">2 Críticos</Badge>
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200">4 Médios</Badge>
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">1 Baixo</Badge>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 overflow-hidden">
                <div className="flex flex-col items-center">
                  <span className="text-xs text-gray-500 mb-1">Riscos Societários</span>
                  <span className="text-2xl font-bold text-gray-800">8</span>
                  <div className="mt-2 flex gap-2 flex-wrap">
                    <Badge className="bg-rose-100 text-rose-700 border-rose-200">2 Críticos</Badge>
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200">3 Médios</Badge>
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">3 Baixos</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <MapaRiscosDetalhado />
      </div>
    </div>
  )
}
