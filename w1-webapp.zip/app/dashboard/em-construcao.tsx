"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"

interface EmConstrucaoProps {
  titulo: string
  descricao: string
  voltarPara: {
    texto: string
    link: string
  }
  tempoRedirecionamento?: number
}

export default function EmConstrucao({
  titulo,
  descricao,
  voltarPara,
  tempoRedirecionamento = 0, // 0 para não redirecionar automaticamente
}: EmConstrucaoProps) {
  const router = useRouter()
  const [contador, setContador] = useState(tempoRedirecionamento)

  useEffect(() => {
    if (tempoRedirecionamento > 0) {
      const interval = setInterval(() => {
        setContador((prevContador) => {
          if (prevContador <= 1) {
            clearInterval(interval)
            router.push(voltarPara.link)
            return 0
          }
          return prevContador - 1
        })
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [router, voltarPara.link, tempoRedirecionamento])

  return (
    <div className="flex min-h-[80vh] flex-col items-center justify-center text-center p-4">
      <div className="max-w-md space-y-6">
        <div className="space-y-2">
          <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-gray-100 p-2 dark:bg-gray-800">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-10 w-10 text-gray-500 dark:text-gray-400"
            >
              <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"></path>
              <path d="M12 14v-4"></path>
              <path d="M12 6h.01"></path>
            </svg>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">{titulo}</h1>
          <p className="text-gray-500 dark:text-gray-400 md:text-lg">{descricao}</p>
        </div>
        <div className="flex justify-center">
          <Link
            href={voltarPara.link}
            className="inline-flex h-10 items-center justify-center rounded-md bg-teal-600 px-8 text-sm font-medium text-white shadow transition-colors hover:bg-teal-700 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-gray-950 disabled:pointer-events-none disabled:opacity-50 dark:bg-teal-700 dark:hover:bg-teal-600 dark:focus-visible:ring-gray-300"
          >
            {voltarPara.texto}
            {contador > 0 && ` (${contador}s)`}
          </Link>
        </div>
      </div>
    </div>
  )
}
