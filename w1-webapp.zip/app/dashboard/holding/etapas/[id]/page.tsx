import { ArrowLeft, Calendar, CheckCircle, Clock, Download, FileText, MessageSquare, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function EtapaDetalhes({ params }: { params: { id: string } }) {
  // Dados de exemplo para a etapa
  const etapaId = Number.parseInt(params.id)

  // Dados fictícios para a etapa atual
  const etapa = {
    id: etapaId,
    titulo: "Escolha da Estrutura Jurídica e Tipo de Holding",
    descricao:
      "Nesta etapa, definimos o modelo jurídico mais adequado para sua holding com base nos seus objetivos patrimoniais e sucessórios.",
    status: "current",
    dataInicio: "01/05/2023",
    previsaoConclusao: "25/05/2023",
    responsavel: "Dr. Carlos Mendes",
    cargo: "Advogado Especialista em Direito Societário",
    progresso: 60,
    documentos: [
      {
        id: 1,
        nome: "Proposta de Estrutura Jurídica",
        tipo: "PDF",
        tamanho: "2.4 MB",
        data: "15/05/2023",
        status: "Aguardando revisão",
        statusColor: "blue",
      },
      {
        id: 2,
        nome: "Comparativo de Tipos de Holding",
        tipo: "PDF",
        tamanho: "1.8 MB",
        data: "10/05/2023",
        status: "Disponível para download",
        statusColor: "teal",
      },
      {
        id: 3,
        nome: "Análise Tributária das Opções",
        tipo: "PDF",
        tamanho: "3.2 MB",
        data: "12/05/2023",
        status: "Disponível para download",
        statusColor: "teal",
      },
    ],
    tarefas: [
      {
        id: 1,
        titulo: "Revisar proposta de estrutura jurídica",
        descricao: "Analisar o documento enviado e aprovar ou solicitar ajustes.",
        prazo: "25/05/2023",
        status: "pendente",
        prioridade: "alta",
      },
      {
        id: 2,
        titulo: "Agendar reunião para esclarecimentos",
        descricao: "Caso tenha dúvidas sobre a proposta, agende uma reunião com nosso especialista.",
        prazo: "20/05/2023",
        status: "opcional",
        prioridade: "média",
      },
    ],
    proximos_passos: [
      "Após sua aprovação da estrutura jurídica, iniciaremos a elaboração do contrato social.",
      "Será necessário definir as cláusulas específicas de proteção patrimonial.",
      "Prepararemos toda a documentação para registro na Junta Comercial.",
    ],
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <Link href="/dashboard/holding" className="inline-flex items-center text-teal-400 hover:text-teal-300">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span>Voltar para visão geral</span>
        </Link>
      </div>

      <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="max-w-4xl">
          <div className="flex flex-col md:flex-row md:items-center">
            <h1 className="text-3xl font-bold text-black">Etapa {etapaId}:</h1>
            <h2 className="md:ml-2 text-3xl font-bold text-teal-400">{etapa.titulo}</h2>
          </div>
          <p className="mt-2 text-base text-black leading-relaxed">{etapa.descricao}</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-gray-800 border-gray-700 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-2xl text-white">Status da Etapa</CardTitle>
              <CardDescription className="text-gray-400">Acompanhe o progresso desta etapa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-medium text-white">Progresso Atual</span>
                  <span className="text-lg font-medium text-teal-400">{etapa.progresso}%</span>
                </div>
                <div className="h-3 w-full rounded-full bg-gray-700">
                  <div
                    className="h-3 rounded-full bg-gradient-to-r from-teal-400 to-cyan-500"
                    style={{ width: `${etapa.progresso}%` }}
                  ></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center rounded-lg bg-gray-700 p-4">
                    <Calendar className="mr-3 h-5 w-5 text-teal-400 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-gray-400">Data de Início</p>
                      <p className="text-lg font-medium text-white truncate">{etapa.dataInicio}</p>
                    </div>
                  </div>
                  <div className="flex items-center rounded-lg bg-gray-700 p-4">
                    <Clock className="mr-3 h-5 w-5 text-amber-400 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-gray-400">Previsão de Conclusão</p>
                      <p className="text-lg font-medium text-white truncate">{etapa.previsaoConclusao}</p>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg bg-gray-700 p-4">
                  <p className="text-sm text-gray-400 mb-2">Responsável por esta etapa</p>
                  <div className="flex items-center">
                    <div className="mr-3 h-10 w-10 rounded-full bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center text-gray-900 font-bold flex-shrink-0">
                      CM
                    </div>
                    <div className="min-w-0">
                      <p className="text-lg font-medium text-white truncate">{etapa.responsavel}</p>
                      <p className="text-sm text-gray-400 truncate">{etapa.cargo}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-2xl text-white">Documentos da Etapa</CardTitle>
              <CardDescription className="text-gray-400">
                Documentos relacionados a esta etapa do processo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {etapa.documentos.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between rounded-lg bg-gray-700 p-4 hover:bg-gray-700/70 transition-colors overflow-hidden"
                  >
                    <div className="flex items-center min-w-0 flex-1">
                      <div className="mr-4 rounded-md bg-gray-600 p-2 flex-shrink-0">
                        <FileText className="h-6 w-6 text-gray-300" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-lg font-medium text-white truncate">{doc.nome}</h3>
                        <p className="text-sm text-gray-400 truncate">
                          {doc.tipo} • {doc.tamanho} • {doc.data}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 flex-shrink-0 ml-4">
                      <span
                        className={`inline-flex items-center rounded-full bg-${doc.statusColor}-500/20 px-2.5 py-1 text-xs font-medium text-${doc.statusColor}-400 whitespace-nowrap`}
                      >
                        {doc.status}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-gray-400 hover:text-white flex-shrink-0"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                <div className="mt-6 flex justify-center">
                  <Button className="bg-teal-500 text-black hover:bg-teal-400">
                    <Upload className="mr-2 h-4 w-4" />
                    Enviar Novo Documento
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <Card className="bg-gray-800 border-gray-700 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl text-white">Ações Necessárias</CardTitle>
              <CardDescription className="text-gray-400">Tarefas que requerem sua atenção</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {etapa.tarefas.map((tarefa) => (
                  <div
                    key={tarefa.id}
                    className={`rounded-lg p-4 overflow-hidden ${
                      tarefa.prioridade === "alta"
                        ? "bg-red-500/10 border border-red-500/30"
                        : "bg-amber-500/10 border border-amber-500/30"
                    }`}
                  >
                    <h3
                      className={`text-lg font-medium mb-2 ${
                        tarefa.prioridade === "alta" ? "text-red-300" : "text-amber-300"
                      }`}
                    >
                      {tarefa.titulo}
                    </h3>
                    <p className="text-sm text-gray-300 mb-3 leading-relaxed">{tarefa.descricao}</p>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <span className="text-xs text-gray-400">Prazo: {tarefa.prazo}</span>
                      <Button
                        size="sm"
                        className={`w-full sm:w-auto ${
                          tarefa.prioridade === "alta"
                            ? "bg-red-500 text-white hover:bg-red-600"
                            : "bg-amber-500 text-black hover:bg-amber-600"
                        }`}
                      >
                        {tarefa.status === "pendente" ? "Realizar Agora" : "Agendar"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl text-white">Próximos Passos</CardTitle>
              <CardDescription className="text-gray-400">O que acontecerá após esta etapa</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {etapa.proximos_passos.map((passo, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="mr-2 h-5 w-5 text-teal-400 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-300 leading-relaxed">{passo}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl text-white">Precisa de Ajuda?</CardTitle>
              <CardDescription className="text-gray-400">Entre em contato com nossa equipe</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button className="w-full bg-teal-500 text-black hover:bg-teal-400">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Agendar Reunião
                </Button>
                <Button variant="outline" className="w-full border-teal-400/30 text-teal-400 hover:bg-teal-400/10">
                  Enviar Mensagem
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
