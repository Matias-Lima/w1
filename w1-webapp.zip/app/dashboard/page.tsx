"use client"

import { useState, useEffect } from "react"
import { Home, TrendingUp, Shield, FileText, Calendar, Users } from "lucide-react"
import { CardMetric } from "@/components/dashboard/card-metric"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

// Paleta de cores com ordem de prioridade ajustada
const COLORS = {
  primary: "#0072B2", // Azul escuro (principal)
  secondary: "#E69F00", // Laranja (secundária)
  tertiary: "#009E73", // Verde (terciária)
  quaternary: "#CC79A7", // Rosa (quaternária)
  quinary: "#000000", // Preto (quinta)
  senary: "#56B4E9", // Azul claro (sexta)
  darkBlue: "#0072B2", // Azul escuro (alternativa)
  darkOrange: "#D55E00", // Laranja escuro (alternativa)
  gray: "#999999", // Cinza (alternativa)
}

export default function DashboardPage() {
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratação
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="space-y-6 pb-10 px-2 sm:px-4">
      <div className="flex flex-col gap-2">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-black">Visão Geral do Patrimônio</h1>
            <p className="text-sm sm:text-base text-gray-700 mt-1">
              Acompanhe a evolução e proteção do seu patrimônio familiar
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <CardMetric
          title="Patrimônio Total"
          value="R$ 4.523.189"
          description="Valor total dos seus ativos"
          trend={{ value: "8%", isPositive: true }}
          icon={Home}
          className="animate-fade-in"
          style={{ animationDelay: "0ms" }}
        />
        <CardMetric
          title="Economia Tributária"
          value="R$ 254.365"
          description="Economia com a holding"
          trend={{ value: "15%", isPositive: true }}
          icon={FileText}
          iconColor="text-emerald-400"
          className="animate-fade-in"
          style={{ animationDelay: "100ms" }}
        />
        <CardMetric
          title="Nível de Proteção"
          value="85%"
          description="Proteção patrimonial atual"
          trend={{ value: "23%", isPositive: true }}
          icon={Shield}
          iconColor="text-blue-400"
          className="animate-fade-in"
          style={{ animationDelay: "200ms" }}
        />
        <CardMetric
          title="Crescimento Projetado"
          value="12,5%"
          description="Projeção anual com holding"
          trend={{ value: "4.2%", isPositive: true }}
          icon={TrendingUp}
          iconColor="text-teal-400"
          className="animate-fade-in"
          style={{ animationDelay: "300ms" }}
        />
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-2">
        <Card
          className="border-gray-200 bg-white text-gray-900 backdrop-blur-sm hover-lift transition-all duration-300 animate-fade-in"
          style={{ animationDelay: "400ms" }}
        >
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-base sm:text-lg font-medium text-black">Evolução do Patrimônio</CardTitle>
            <CardDescription className="text-sm text-gray-700">
              Crescimento projetado nos próximos 5 anos
            </CardDescription>
          </CardHeader>
          <CardContent className="p-2 sm:p-6 pt-0 sm:pt-0">
            <div className="h-[250px] sm:h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={[
                    { ano: "2023", comHolding: 4500000, semHolding: 4500000 },
                    { ano: "2024", comHolding: 5062500, semHolding: 4815000 },
                    { ano: "2025", comHolding: 5695312, semHolding: 5152050 },
                    { ano: "2026", comHolding: 6407227, semHolding: 5512693 },
                    { ano: "2027", comHolding: 7208130, semHolding: 5898582 },
                    { ano: "2028", comHolding: 8109146, semHolding: 6311483 },
                  ]}
                  margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="ano" stroke="#6B7280" tick={{ fontSize: 12 }} />
                  <YAxis
                    stroke="#6B7280"
                    tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
                    tick={{ fontSize: 12 }}
                    width={40}
                  />
                  <Tooltip
                    formatter={(value) => [`R$ ${value.toLocaleString()}`, ""]}
                    contentStyle={{
                      backgroundColor: "#FFFFFF",
                      borderColor: "#E5E7EB",
                      boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
                      borderRadius: "4px",
                    }}
                    itemStyle={{ padding: "2px 0" }}
                    labelStyle={{ fontWeight: "bold", marginBottom: "5px" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                  <Area
                    type="monotone"
                    dataKey="comHolding"
                    name="Com Holding"
                    stroke={COLORS.primary}
                    fill={COLORS.primary}
                    fillOpacity={0.7}
                    strokeWidth={2}
                    activeDot={{ r: 8, strokeWidth: 1 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="semHolding"
                    name="Sem Holding"
                    stroke={COLORS.secondary}
                    fill={COLORS.secondary}
                    fillOpacity={0.5}
                    strokeWidth={2}
                    activeDot={{ r: 6, strokeWidth: 1 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card
          className="border-gray-200 bg-white text-gray-900 backdrop-blur-sm hover-lift transition-all duration-300 animate-fade-in"
          style={{ animationDelay: "500ms" }}
        >
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-base sm:text-lg font-medium text-black">Composição do Patrimônio</CardTitle>
            <CardDescription className="text-sm text-gray-700">Distribuição atual dos seus ativos</CardDescription>
          </CardHeader>
          <CardContent className="p-2 sm:p-6 pt-0 sm:pt-0">
            <div className="h-[250px] sm:h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: "Imóveis", valor: 65, color: COLORS.primary },
                      { name: "Investimentos", valor: 20, color: COLORS.secondary },
                      { name: "Participações", valor: 10, color: COLORS.tertiary },
                      { name: "Outros", valor: 5, color: COLORS.quaternary },
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={90}
                    fill="#8884d8"
                    dataKey="valor"
                    label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }) => {
                      const RADIAN = Math.PI / 180
                      const radius = innerRadius + (outerRadius - innerRadius) * 0.5
                      const x = cx + radius * Math.cos(-midAngle * RADIAN)
                      const y = cy + radius * Math.sin(-midAngle * RADIAN)

                      return (
                        <text
                          x={x}
                          y={y}
                          fill="#000000"
                          textAnchor={x > cx ? "start" : "end"}
                          dominantBaseline="central"
                          fontSize={12}
                          fontWeight="bold"
                        >
                          {`${(percent * 100).toFixed(0)}%`}
                        </text>
                      )
                    }}
                  >
                    {[
                      { name: "Imóveis", valor: 65, color: COLORS.primary },
                      { name: "Investimentos", valor: 20, color: COLORS.secondary },
                      { name: "Participações", valor: 10, color: COLORS.tertiary },
                      { name: "Outros", valor: 5, color: COLORS.quaternary },
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value) => [`${value}%`, ""]}
                    contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-3">
        <Card
          className="border-gray-200 bg-white text-gray-900 backdrop-blur-sm hover-lift transition-all duration-300 md:col-span-2 animate-fade-in"
          style={{ animationDelay: "600ms" }}
        >
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-base sm:text-lg font-medium text-black">Economia Tributária Projetada</CardTitle>
            <CardDescription className="text-sm text-gray-700">Economia anual por tipo de tributo</CardDescription>
          </CardHeader>
          <CardContent className="p-2 sm:p-6 pt-0 sm:pt-0">
            <div className="h-[250px] sm:h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { ano: "2023", IR: 120000, ITCMD: 0, ITBI: 45000 },
                    { ano: "2024", IR: 135000, ITCMD: 0, ITBI: 48000 },
                    { ano: "2025", IR: 152000, ITCMD: 180000, ITBI: 52000 },
                    { ano: "2026", IR: 171000, ITCMD: 0, ITBI: 56000 },
                    { ano: "2027", IR: 192000, ITCMD: 0, ITBI: 61000 },
                  ]}
                  margin={{ top: 20, right: 10, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="ano" stroke="#6B7280" tick={{ fontSize: 12 }} />
                  <YAxis
                    stroke="#6B7280"
                    tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                    tick={{ fontSize: 12 }}
                    width={40}
                  />
                  <Tooltip
                    formatter={(value) => [`R$ ${value.toLocaleString()}`, ""]}
                    contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                  <Bar dataKey="IR" name="Imposto de Renda" fill={COLORS.primary} />
                  <Bar dataKey="ITCMD" name="ITCMD (Herança)" fill={COLORS.secondary} />
                  <Bar dataKey="ITBI" name="ITBI (Transmissão)" fill={COLORS.tertiary} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-3 sm:space-y-4 animate-fade-in" style={{ animationDelay: "700ms" }}>
          <Card className="border-gray-200 bg-white text-gray-900 backdrop-blur-sm hover-lift transition-all duration-300">
            <CardHeader className="p-4 sm:p-6 pb-2">
              <CardTitle className="text-base sm:text-lg font-medium text-black">Próximas Etapas</CardTitle>
              <CardDescription className="text-sm text-gray-700">
                Seu progresso na constituição da holding
              </CardDescription>
            </CardHeader>
            <CardContent className="p-4 sm:p-6 pt-0">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div
                    className="h-5 w-5 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                    style={{ borderColor: COLORS.primary }}
                  >
                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: COLORS.primary }}></div>
                  </div>
                  <span className="text-sm text-gray-900">Análise patrimonial concluída</span>
                </div>
                <div className="flex items-center gap-3">
                  <div
                    className="h-5 w-5 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                    style={{ borderColor: COLORS.primary }}
                  >
                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: COLORS.primary }}></div>
                  </div>
                  <span className="text-sm text-gray-900">Planejamento tributário concluído</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-5 w-5 rounded-full border-2 border-gray-600 flex items-center justify-center flex-shrink-0">
                    <div className="h-2 w-2 rounded-full bg-transparent"></div>
                  </div>
                  <span className="text-sm text-gray-700">Elaboração do contrato social</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-5 w-5 rounded-full border-2 border-gray-600 flex items-center justify-center flex-shrink-0">
                    <div className="h-2 w-2 rounded-full bg-transparent"></div>
                  </div>
                  <span className="text-sm text-gray-700">Registro da holding</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-5 w-5 rounded-full border-2 border-gray-600 flex items-center justify-center flex-shrink-0">
                    <div className="h-2 w-2 rounded-full bg-transparent"></div>
                  </div>
                  <span className="text-sm text-gray-700">Transferência de bens</span>
                </div>
              </div>

              <Button
                variant="ghost"
                className="w-full mt-4 hover:bg-gray-100/50 text-sm"
                style={{ color: COLORS.primary }}
              >
                Ver todas as etapas
              </Button>
            </CardContent>
          </Card>

          <Card className="border-gray-200 bg-white text-gray-900 backdrop-blur-sm hover-lift transition-all duration-300">
            <CardHeader className="p-4 sm:p-6 pb-2">
              <CardTitle className="text-base sm:text-lg font-medium text-black">Próxima Reunião</CardTitle>
              <CardDescription className="text-sm text-gray-700">Acompanhamento com seu consultor</CardDescription>
            </CardHeader>
            <CardContent className="p-4 sm:p-6 pt-0">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div
                    className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full"
                    style={{ backgroundColor: `${COLORS.primary}20`, color: COLORS.primary }}
                  >
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Revisão do Contrato Social</p>
                    <p className="text-xs text-gray-700">28/05/2023 - 14:00</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div
                    className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full"
                    style={{ backgroundColor: `${COLORS.secondary}20`, color: COLORS.secondary }}
                  >
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Dr. Carlos Mendes</p>
                    <p className="text-xs text-gray-700">Especialista em Holding Familiar</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
