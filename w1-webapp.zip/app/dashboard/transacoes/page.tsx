import EmConstrucao from "../em-construcao"

export default function TransacoesPage() {
  return (
    <EmConstrucao
      titulo="Módulo de Transações em Desenvolvimento"
      descricao="O módulo de transações está sendo finalizado e estará disponível para uso em breve. Você poderá acompanhar todas as suas movimentações financeiras aqui."
      voltarPara={{
        texto: "Voltar para o Dashboard",
        link: "/dashboard",
      }}
    />
  )
}
