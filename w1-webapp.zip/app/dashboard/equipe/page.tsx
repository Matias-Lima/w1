import EmConstrucao from "../em-construcao"

export default function EquipePage() {
  return (
    <EmConstrucao
      titulo="Gestão de Equipe em Desenvolvimento"
      descricao="O módulo de gestão de equipe está sendo finalizado. Em breve você poderá gerenciar permissões e acessos dos membros da sua empresa."
      voltarPara={{
        texto: "Voltar para o Dashboard",
        link: "/dashboard",
      }}
    />
  )
}
